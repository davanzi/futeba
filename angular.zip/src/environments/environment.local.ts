import { globalConfig } from './global-config';

export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080/casco/api/v1/',
  apiMultimidiaUrl: 'http://localhost:8080/casco/',
  sessionTimeoutMinutes: globalConfig.sessionTimeoutMinutes,
  sessionAlertMinutes: globalConfig.sessionAlertMinutes,
  secretKey: globalConfig.secretKey,
  version: globalConfig.version
};