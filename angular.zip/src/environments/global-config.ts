import packageJson from '../../package.json';

// Configurações globais compartilhadas entre todos os ambientes
export const globalConfig = {
    secretKey: 'f3a529a2dbbff4696ca9feba186ec788',
    version: '1.0.0.27',
    sessionTimeoutMinutes: 10,
    sessionAlertMinutes: 0.5,
};
