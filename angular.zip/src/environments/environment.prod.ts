import { globalConfig } from './global-config';

export const environment = {
  production: true,
  apiBaseUrl: 'https://dev-apidesenvolvimentos.space/casco/api/v1/',
  apiMultimidiaUrl: 'https://dev-apidesenvolvimentos.space/casco/',
  sessionTimeoutMinutes: globalConfig.sessionTimeoutMinutes,
  sessionAlertMinutes: globalConfig.sessionAlertMinutes,
  secretKey: globalConfig.secretKey,
  version: globalConfig.version
};
