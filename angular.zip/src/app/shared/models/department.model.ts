export interface Department {
  id: string | null;
  name: string;
  active: boolean;
}
