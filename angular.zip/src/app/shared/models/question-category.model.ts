export interface QuestionCategory {
  id: string | null;
  name: string;
  active: boolean;
}