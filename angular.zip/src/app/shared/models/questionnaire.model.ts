// Modelo para Questionário e suas dependências
import { Question } from './question.model';
import { Department } from './department.model';

export interface Questionnaire {
  id: string | null;
  name: string;
  questions: Question[];
  template: boolean;
  active: boolean;
  department?: Department;
}

export interface QuestionnaireListResponse {
  data: Questionnaire[];
  success: boolean;
  errors: string;
}

export interface QuestionnaireRegisterRequest {
  id: string | null;
  name: string;
  questionIds: string[];
  template: boolean;
  active: boolean;
  department?: Department;
}

export interface QuestionnaireRegisterResponse {
  data: Questionnaire;
  success: boolean;
  errors: string;
}
