import { AnswerType } from '../constants/answer-type.enum';
import { QuestionCategory } from './question-category.model';

export interface AnswerOption {
  id: string | null;
  description?: string;
  image?: string;
  correct: boolean;
}

export interface Answer {
  id: string | null;
  answerType: AnswerType;
  descriptiveContent?: string;
  answerOptions?: AnswerOption[];
}

export interface Question {
  id: string | null;
  title: string;
  content: string;
  video: string | null;
  image: string | null;
  answer?: Answer;
  questionCategory: QuestionCategory;
  template: boolean;
}
