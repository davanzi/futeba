export interface User {
  id: string | null;
  name: string;
  email: string;
  cpf: string;
  password?: string;
  profileImage: string; // Agora é apenas uma string base64
  profiles: {
    id: number | string | null;
    permission: {
      id: number | string | null;
      description: string;
      name: string;
    };
    fullAccess: boolean;
  }[];
  active: boolean;
  lastLogin: string;
  temporaryPassword: boolean;
  token: string;
}
