import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VersionComponent } from './utils/version/version.component';
import { LoadingComponent } from './utils/loading/loading.component';

@NgModule({
  imports: [
    CommonModule,
    MatCardModule,
    DragDropModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [
    LoadingComponent,
    VersionComponent,
  ],
  exports: [
    CommonModule,
    MatCardModule,
    DragDropModule,
    FormsModule,
    ReactiveFormsModule,
    LoadingComponent,
    VersionComponent,
  ],
})
export class SharedModule {}