import { Component } from '@angular/core';
import { LoadingService } from './loading.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-full-screen-loading',
  standalone: true,
  imports: [CommonModule, MatProgressSpinnerModule],
  template: `
    <div class="overlay" *ngIf="loadingService.isLoading$ | async">
      <div class="spinner-container">
        <img src="/assets/images/loading/loading.gif" alt="Carregando..." class="loading-gif" />
      </div>
    </div>
  `,
  styles: [
    `
    .overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }
    .spinner-container {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .loading-gif {
      width: 100px;
      height: 100px;
    }
    `
  ]
})
export class LoadingComponent {
  constructor(public loadingService: LoadingService) {}
}
