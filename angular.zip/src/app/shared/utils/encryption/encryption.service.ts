import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../../../environments/environment';

/**
 * Serviço para criptografar e descriptografar strings usando AES.
 * A chave deve ser a mesma utilizada no backend para compatibilidade.
 */
@Injectable({
  providedIn: 'root',
})
export class EncryptionService {
  private secretKey = environment.secretKey;

  /**
   * Criptografa uma string.
   * @param data Texto puro a ser criptografado
   * @returns Texto criptografado (base64)
   */
  encrypt2(data: string): string {
    return CryptoJS.AES.encrypt(data, this.secretKey).toString();
  }

  /**
   * Criptografa uma string.
   * @param data Texto puro a ser criptografado
   * @returns Texto criptografado (base64)
   */
  public encrypt(data: string): string {
    // Gerar vetor de inicialização (IV) aleatório (16 bytes para AES)
    const iv = CryptoJS.lib.WordArray.random(16);

    // Criptografar os dados (Modo CBC com PKCS7 Padding)
    const encrypted = CryptoJS.AES.encrypt(data, CryptoJS.enc.Utf8.parse(this.secretKey), {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });

    // Concatene o IV com os dados criptografados e converta para Base64
    const result = iv.concat(encrypted.ciphertext);
    return CryptoJS.enc.Base64.stringify(result);
  }

  /**
   * Descriptografa uma string criptografada.
   * @param encryptedData Texto criptografado (base64)
   * @returns Texto puro
   */
  decrypt2(encryptedData: string): string {
    const bytes = CryptoJS.AES.decrypt(encryptedData, this.secretKey);
    return bytes.toString(CryptoJS.enc.Utf8);
  }

  /**
 * Descriptografa uma string criptografada.
 * @param encryptedData Texto criptografado (base64)
 * @returns Texto puro
 */
  public decrypt(encryptedData: string): string {
    // Converter Base64 de volta para um WordArray
    const rawData = CryptoJS.enc.Base64.parse(encryptedData);

    // Extrair o IV (primeiros 16 bytes) e o texto criptografado
    const iv = CryptoJS.lib.WordArray.create(rawData.words.slice(0, 4), 16);
    const ciphertext = CryptoJS.lib.WordArray.create(
      rawData.words.slice(4),
      rawData.sigBytes - 16
    );

    // Descriptografar os dados
    const decrypted = CryptoJS.AES.decrypt(
      { ciphertext: ciphertext } as any, // Setando os dados criptografados manualmente
      CryptoJS.enc.Utf8.parse(this.secretKey),
      {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    );

    // Retornar o texto descriptografado
    return decrypted.toString(CryptoJS.enc.Utf8);
  }

  getItem(key: string) {
    const encryptedData = sessionStorage.getItem(key);
    if (encryptedData) {
      return this.decrypt(encryptedData);
    }
    return null;
  }

  setItem(key: string, value: string) {
    if (key) {
      const encryptedData = this.encrypt(value.toString());
      sessionStorage.setItem(key, encryptedData);
    }
  }

  removeItem(key: string) {
    sessionStorage.removeItem(key);
  }
}