import { environment } from '../../../../environments/environment';
import { Component } from '@angular/core';

@Component({
  selector: 'app-version',
  template: `<div>v{{ version }}</div>`
})
export class VersionComponent {
  version = environment.version;
}
