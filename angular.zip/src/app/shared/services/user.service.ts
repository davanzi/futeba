import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { CONST_API_ENDPOINTS } from '../constants/api-endpoints.const';
import { User } from '../models/user.model';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { AuthService } from '../../core/services/auth.service';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private searchUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.USER_SEARCH}`;
  private changeStatusUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.USER_CHANGE_STATUS}`;
  private updateUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.USER_UPDATE}`;
  private updateProfileUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.USER_UPDATE_PROFILE}`;
  private resetPasswordUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.RESET_PASSWORD}`;
  private registerInternalUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.USER_REGISTER_INTERNAL}`;
  private registerUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.USER_REGISTER}`;
  private maskedEmailUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.MASKED_EMAIL}`;

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  searchUsers(
    body: any,
    page: number = 0,
    size: number = 10,
    sort: string = 'name,asc'
  ): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    const params = new HttpParams()
      .set('page', page)
      .set('size', size)
      .set('sort', sort);
    return this.http.post<any>(this.searchUrl, body, { headers, params }).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Erro ao buscar usuários';
        return throwError(() => errorMessage);
      })
    );
  }

  changeStatus(userId: string): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<any>(this.changeStatusUrl, {
      headers,
      params: new HttpParams().set('id', userId)
    }).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Erro ao alterar status do usuário';
        return throwError(() => errorMessage);
      })
    );
  }

  updateUser(user: Partial<User>): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<any>(this.updateUrl, user, { headers }).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Erro ao atualizar dados do usuário';
        return throwError(() => errorMessage);
      })
    );
  }

  /**
   * Atualiza o perfil (permissões) do usuário
   * @param data { idUser: number, profiles: { idPermission: number, fullAccess: boolean }[] }
   */
  updateUserProfile(data: { idUser: number; profiles: { idPermission: number; fullAccess: boolean }[] }): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<any>(this.updateProfileUrl, data, { headers }).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Erro ao atualizar perfil do usuário';
        return throwError(() => errorMessage);
      })
    );
  }

  /**
   * Reseta a senha do usuário (admin)
   * @param email string
   * @param cpf string
   */
  resetPassword(email: string, cpf: string): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<any>(this.resetPasswordUrl, { email, cpf }, { headers }).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Erro ao resetar senha do usuário';
        return throwError(() => errorMessage);
      })
    );
  }

  registerInternal(user: any): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<any>(this.registerInternalUrl, user, { headers }).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Registro interno falhou';
        return throwError(() => errorMessage);
      })
    );
  }

  register(user: User): Observable<any> {
    return this.http.post<any>(this.registerUrl, user).pipe(
      map((response) => {
        if (response.success) {
          return response.data;
        }
        throw new Error(response.errors || 'Registration failed');
      }),
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Registro falhou';
        return throwError(() => errorMessage);
      })
    );
  }

  /**
   * Obtém o e-mail mascarado a partir do CPF
   */
  getMaskedEmail(cpf: string): Observable<{ data: string; success: boolean; errors: string }> {
    return this.http.get<{ data: string; success: boolean; errors: string }>(
      `${this.maskedEmailUrl}?cpf=${cpf}`
    ).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Erro ao buscar e-mail';
        return throwError(() => errorMessage);
      })
    );
  }

  /**
   * Reseta a senha do usuário (público)
   */
  resetPasswordPublic(payload: { cpf: string; email: string }): Observable<{ data: boolean; success: boolean; errors: string }> {
    return this.http.post<{ data: boolean; success: boolean; errors: string }>(
      this.resetPasswordUrl,
      payload
    ).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Erro ao resetar a senha';
        return throwError(() => errorMessage);
      })
    );
  }
}
