import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Question } from '../models/question.model';
import { QuestionCategory } from '../models/question-category.model';
import { environment } from '../../../environments/environment';
import { EncryptionService } from '../utils/encryption/encryption.service';
import { CONST_API_ENDPOINTS } from '../constants/api-endpoints.const';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from './notification.service';

interface QuestionSearchResponse {
  data: {
    totalElements: number;
    totalPages: number;
    numberOfElements: number;
    first: boolean;
    last: boolean;
    pageable: any;
    size: number;
    content: Question[];
    number: number;
    sort: any;
    empty: boolean;
  };
  success: boolean;
  errors: string | null;
}

interface QuestionCategoryResponse {
  data: QuestionCategory[];
  success: boolean;
  errors: string | null;
}

@Injectable({ providedIn: 'root' })
export class QuestionService {
  private searchUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.QUESTION_SEARCH}`;
  private registerOrUpdateUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.QUESTION_REGISTER_OR_UPDATE}`;
  private deleteUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.QUESTION_DELETE}`;

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  searchQuestions(
    body: Partial<Question>,
    page: number = 0,
    size: number = 10,
    sort: string = 'title,asc'
  ): Observable<QuestionSearchResponse> {
    const headers = this.authService.getAuthHeaders();
    const params = new HttpParams()
      .set('page', page)
      .set('size', size)
      .set('sort', sort);
    return this.http.post<QuestionSearchResponse>(
      this.searchUrl,
      body,
      { headers, params }
    ).pipe(
      catchError((error) => {
        const errorMessage = error.error?.message || 'Erro ao buscar questões';
        this.notificationService.showError(errorMessage);
        return throwError(() => errorMessage);
      })
    );
  }
  
  registerOrUpdateQuestion(body: any) {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<any>(
      this.registerOrUpdateUrl,
      body,
      { headers }
    ).pipe(
      catchError((error) => {
        const errorMessage = error.error?.message || 'Erro ao cadastrar/atualizar questão';
        this.notificationService.showError(errorMessage);
        return throwError(() => errorMessage);
      })
    );
  }

  /**
   * Exclui uma questão pelo id
   */
  deleteQuestion(id: string) {
    const headers = this.authService.getAuthHeaders();
    return this.http.delete<any>(
      `${this.deleteUrl}/${id}`,
      { headers }
    ).pipe(
      catchError((error) => {
        const errorMessage = error.error?.message || 'Erro ao excluir questão';
        this.notificationService.showError(errorMessage);
        return throwError(() => errorMessage);
      })
    );
  }
}
