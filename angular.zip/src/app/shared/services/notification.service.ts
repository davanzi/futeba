import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  constructor(private snackBar: MatSnackBar) {} // Inject MatSnackBar

  showError(message: string): void {
    this.snackBar.open(message, 'Fechar', {
      duration: 5000, // Duration in milliseconds
      panelClass: ['error-snackbar'], // Custom class for styling
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }

  showInfo(message: string): void {
    this.snackBar.open(message, 'Fechar', {
      duration: 3000,
      panelClass: ['info-snackbar'],
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }

  showWarn(message: string): void {
    this.snackBar.open(message, 'Fechar', {
      duration: 4000,
      panelClass: ['warn-snackbar'],
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }
}
