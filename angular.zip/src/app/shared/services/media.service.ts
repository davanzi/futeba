import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { EncryptionService } from '../utils/encryption/encryption.service';
import { AuthService } from '../../core/services/auth.service';
import { CONST_API_ENDPOINTS } from '../constants/api-endpoints.const';

@Injectable({ providedIn: 'root' })
export class MediaService {
  private apiUrl = environment.apiBaseUrl + CONST_API_ENDPOINTS.MEDIA_UPLOAD_IMAGE;
  private apiVideoUrl = environment.apiBaseUrl + CONST_API_ENDPOINTS.MEDIA_UPLOAD_VIDEO;

  constructor(private http: HttpClient, private encryptionService: EncryptionService, private authService: AuthService) {}

  uploadImage(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('image', file);
    const token = this.authService.getToken();
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.post<any>(this.apiUrl, formData, { headers });
  }

  uploadVideo(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('video', file);
    const token = this.authService.getToken();
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.post<any>(this.apiVideoUrl, formData, { headers });
  }
}
