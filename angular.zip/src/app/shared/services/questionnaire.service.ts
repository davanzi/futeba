import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import {
  QuestionnaireListResponse,
  QuestionnaireRegisterRequest,
  QuestionnaireRegisterResponse
} from '../models/questionnaire.model';
import { CONST_API_ENDPOINTS } from '../constants/api-endpoints.const';
import { AuthService } from '../../core/services/auth.service';

@Injectable({ providedIn: 'root' })
export class QuestionnaireService {
  private baseUrl = environment.apiBaseUrl;
  private listUrl = `${this.baseUrl}${CONST_API_ENDPOINTS.QUESTIONNAIRE_LIST}`;
  private registerOrUpdateUrl = `${this.baseUrl}${CONST_API_ENDPOINTS.QUESTIONNAIRE_REGISTER_OR_UPDATE}`;
  private searchUrl = `${this.baseUrl}${CONST_API_ENDPOINTS.QUESTIONNAIRE_SEARCH}`;
  private changeStatusUrl = `${this.baseUrl}${CONST_API_ENDPOINTS.QUESTIONNAIRE_CHANGE_STATUS}`;

  constructor(private http: HttpClient, private authService: AuthService) {}

  list(): Observable<QuestionnaireListResponse> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<QuestionnaireListResponse>(this.listUrl, { headers });
  }

  registerOrUpdate(payload: QuestionnaireRegisterRequest): Observable<QuestionnaireRegisterResponse> {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<QuestionnaireRegisterResponse>(this.registerOrUpdateUrl, payload, { headers });
  }

  searchQuestionnaires(body: any, page: number = 0, size: number = 10, sort: string = 'name,asc'): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    const params = new HttpParams()
      .set('page', page)
      .set('size', size)
      .set('sort', sort);
    return this.http.post<any>(this.searchUrl, body, { headers, params });
  }

  /**
   * Ativa/desativa um questionário
   */
  changeStatus(id: string): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<any>(`${this.changeStatusUrl}?id=${id}`, { headers });
  }

  getById(id: string): Observable<QuestionnaireRegisterResponse> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<QuestionnaireRegisterResponse>(`${this.listUrl}/${id}`, { headers });
  }
}
