import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { CONST_API_ENDPOINTS } from '../constants/api-endpoints.const';
import { Department } from '../models/department.model';
import { AuthService } from '../../core/services/auth.service';

@Injectable({ providedIn: 'root' })
export class DepartmentService {
  private searchUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.DEPARTMENT_SEARCH}`;
  private registerOrUpdateUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.DEPARTMENT_REGISTER_OR_UPDATE}`;
  private changeStatusUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.DEPARTMENT_CHANGE_STATUS}`;

  constructor(private http: HttpClient, private authService: AuthService) {}

  searchDepartments(body: any, page: number = 0, size: number = 10, sort: string = 'name,asc'): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    const params = new HttpParams()
      .set('page', page)
      .set('size', size)
      .set('sort', sort);
    return this.http.post<any>(this.searchUrl, body, { headers, params }).pipe(
      catchError((error) => {
        return throwError(() => error.error?.message || 'Erro ao buscar departamentos');
      })
    );
  }

  registerOrUpdate(department: Department): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<any>(this.registerOrUpdateUrl, department, { headers }).pipe(
      catchError((error) => {
        return throwError(() => error.error?.message || 'Erro ao salvar departamento');
      })
    );
  }

  changeStatus(id: string): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<any>(`${this.changeStatusUrl}?id=${id}`, { headers }).pipe(
      catchError((error) => {
        return throwError(() => error.error?.message || 'Erro ao alterar status do departamento');
      })
    );
  }
}
