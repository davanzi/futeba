import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-password-strength',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './password-strength.component.html',
  styleUrls: ['./password-strength.component.scss']
})
export class PasswordStrengthComponent {
  @Input() password: string = '';

  get strength(): number {
    let score = 0;
    if (this.password.length >= 10) score++;
    if (/[A-Z]/.test(this.password)) score++;
    if (/[a-z]/.test(this.password)) score++;
    if (/[0-9]/.test(this.password)) score++;
    if (/[^A-Za-z0-9]/.test(this.password)) score++;
    return score;
  }

  get strengthColor(): string {
    const colors = ['red', 'orange', 'yellow', 'blue', 'green'];
    return colors[this.strength - 1] || 'red';
  }

  get requirementsNotMet(): boolean {
    return this.strength < 5;
  }

  get showRequirementsMessage(): boolean {
    return this.password.length > 0 && this.requirementsNotMet;
  }
}