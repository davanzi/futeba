// Centralização de rotas, imports dinâmicos e permissões dos módulos privados
import { CONST_PERMISSIONS } from './permissions.const';

export const CONST_ROUTES = {
  HOME: {
    path: 'home',
    import: () => import('../../modules/private/home/home.component').then(m => m.HomeComponent),
    route: '/app/home',
  },
  ACCOUNT: {
    path: 'account',
    import: () => import('../../modules/private/account/account.component').then(m => m.AccountComponent),
    route: '/app/account',
  },
  USER: {
    path: 'user',
    import: () => import('../../modules/private/user/user-list/user-list.component').then(m => m.UserComponent),
    route: '/app/user',
    permission: CONST_PERMISSIONS.USER,
  },
  USER_REGISTER: {
    path: 'user-register',
    import: () => import('../../modules/private/user/user-register/user-register.component').then(m => m.UserRegisterComponent),
    route: '/app/user',
    permission: CONST_PERMISSIONS.USER,
  },
  QUESTION: {
    path: 'question',
    import: () => import('../../modules/private/question/question-list/question-list.component').then(m => m.QuestionListComponent),
    route: '/app/question',
    permission: CONST_PERMISSIONS.QUESTION,
  },
  QUESTION_REGISTER: {
    path: 'question-register',
    import: () => import('../../modules/private/question/question-register/question-register.component').then(m => m.QuestionRegisterComponent),
    route: '/app/question-register',
    permission: CONST_PERMISSIONS.QUESTION,
  },
  UPDATE_PASSWORD: {
    path: 'update-password',
    import: () => import('../../modules/private/update-password/update-password.component').then(m => m.UpdatePasswordComponent),
    route: '/app/update-password',
  },
  QUESTIONNAIRE: {
    path: 'questionnaire',
    import: () => import('../../modules/private/questionnaire/questionnaire-list/questionnaire-list.component').then(m => m.QuestionnaireListComponent),
    route: '/app/questionnaire',
    permission: CONST_PERMISSIONS.QUESTIONNAIRE,
  },
  QUESTIONNAIRE_REGISTER: {
    path: 'questionnaire-register',
    import: () => import('../../modules/private/questionnaire/questionnaire-register/questionnaire-register.component').then(m => m.QuestionnaireRegisterComponent),
    route: '/app/questionnaire-register',
    permission: CONST_PERMISSIONS.QUESTIONNAIRE,
  },
  DEPARTMENT: {
    path: 'department',
    import: () => import('../../modules/private/department/department-list/department-list.component').then(m => m.DepartmentListComponent),
    route: '/app/department',
    permission: CONST_PERMISSIONS.DEPARTMENT,
  },
  DEPARTMENT_REGISTER: {
    path: 'department-register',
    import: () => import('../../modules/private/department/department-register/department-register.component').then(m => m.DepartmentRegisterComponent),
    route: '/app/department-register',
    permission: CONST_PERMISSIONS.DEPARTMENT,
  },
  QUESTION_CATEGORY: {
    path: 'question-category',
    import: () => import('../../modules/private/question-category/question-category-list/question-category-list.component').then(m => m.QuestionCategoryListComponent),
    route: '/app/question-category',
    permission: CONST_PERMISSIONS.QUESTION_CATEGORY,
  },
  QUESTION_CATEGORY_REGISTER: {
    path: 'question-category-register',
    import: () => import('../../modules/private/question-category/question-category-register/question-category-register.component').then(m => m.QuestionCategoryRegisterComponent),
    route: '/app/question-category-register',
    permission: CONST_PERMISSIONS.QUESTION_CATEGORY,
  },
}
