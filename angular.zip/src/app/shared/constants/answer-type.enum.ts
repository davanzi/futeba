
export enum AnswerType {
  DESCRIPTIVE = 'DESCRIPTIVE',
  MULTIPLE_CHOICE_TEXT = 'MULTIPLE_CHOICE_TEXT',
  SINGLE_CHOICE_TEXT = 'SINGLE_CHOICE_TEXT',
  MULTIPLE_CHOICE_IMAGE = 'MULTIPLE_CHOICE_IMAGE',
  SINGLE_CHOICE_IMAGE = 'SINGLE_CHOICE_IMAGE',
  EDITOR = 'EDITOR',
}

export const AnswerTypeDescriptions: Record<AnswerType, string> = {
  [AnswerType.DESCRIPTIVE]: 'Descritiva',
  [AnswerType.MULTIPLE_CHOICE_TEXT]: 'Múltipla escolha (texto)',
  [AnswerType.SINGLE_CHOICE_TEXT]: 'Alternativa (texto)',
  [AnswerType.MULTIPLE_CHOICE_IMAGE]: 'Múltipla escolha (imagem)',
  [AnswerType.SINGLE_CHOICE_IMAGE]: 'Alternativa (imagem)',
  [AnswerType.EDITOR]: 'Editor',
};
