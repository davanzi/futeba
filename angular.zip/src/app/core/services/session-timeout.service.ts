import { Injectable, Inject, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { fromEvent, merge, Subscription, timer } from 'rxjs';
import { debounceTime, tap } from 'rxjs/operators';
import { DOCUMENT } from '@angular/common';
import { NotificationService } from '../../shared/services/notification.service';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class SessionTimeoutService {
  private timeoutMinutes = environment.sessionTimeoutMinutes;
  private alertMinutes = environment.sessionAlertMinutes;
  private userEventsSubscription: Subscription | null = null;
  private timerSubscription: Subscription | null = null;
  private warningTimerSubscription: Subscription | null = null;

  constructor(
    private router: Router,
    private ngZone: NgZone,
    @Inject(DOCUMENT) private document: Document,
    private notificationService: NotificationService,
    private authService: AuthService
  ) {}

  startMonitoring(): void {
    this.ngZone.runOutsideAngular(() => {
      const events = merge(
        fromEvent(this.document, 'mousemove'),
        fromEvent(this.document, 'keydown'),
        fromEvent(this.document, 'click'),
        fromEvent(this.document, 'scroll'),
        fromEvent(this.document, 'touchstart')
      );

      this.userEventsSubscription = events
        .pipe(
          debounceTime(500),
          tap(() => this.resetTimer())
        )
        .subscribe();

      this.resetTimer();
    });
  }

  private resetTimer(): void {
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }
    if (this.warningTimerSubscription) {
      this.warningTimerSubscription.unsubscribe();
    }

    // Timer para expiração total
    this.timerSubscription = timer(this.timeoutMinutes * 60 * 1000).subscribe(() => {
      this.logout();
    });

    // Timer para aviso de expiração
    const warningTime = (this.timeoutMinutes - this.alertMinutes) * 60 * 1000;
    if (warningTime > 0) {
      this.warningTimerSubscription = timer(warningTime).subscribe(() => {
        this.ngZone.run(() => {
          this.notificationService.showWarn(`Sua sessão irá expirar em ${this.alertMinutes * 60} segundos.`);
        });
      });
    }
  }

  logout(): void {
    // Limpa tokens, sessionStorage, etc. e faz logout global
    this.authService.logout();
    this.notificationService.showWarn('Sua sessão expirou. Faça login novamente.');
    this.stopMonitoring();
    // Não precisa navegar manualmente, pois o AuthService já faz isso
  }

  stopMonitoring(): void {
    this.userEventsSubscription?.unsubscribe();
    this.timerSubscription?.unsubscribe();
    this.warningTimerSubscription?.unsubscribe();
  }
}
