import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { User } from '../../shared/models/user.model';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { NotificationService } from '../../shared/services/notification.service';
import { Router } from '@angular/router';
import { CONST_API_ENDPOINTS } from '../../shared/constants/api-endpoints.const';
import { EncryptionService } from '../../shared/utils/encryption/encryption.service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.AUTHENTICATE}`;
  private userSubject = new BehaviorSubject<User | null>(null);
  user$ = this.userSubject.asObservable();
  private user: User | null = null;
  private token: string = '';
  private userId: string = '';

  constructor(
    private http: HttpClient,
    private notificationService: NotificationService,
    private router: Router,
    private encryptionService: EncryptionService
  ) { }

  setToken(token: string) {
    this.token = token;
    this.encryptionService.setItem('auth_token', token);
  }

  /**
   * Retorna o token JWT do usuário autenticado
   */
  getToken() {
    if (!this.token && typeof window !== 'undefined') {
      const stored = this.encryptionService.getItem('auth_token');
      if (stored) this.token = stored;
    }
    return this.token;
  }

  /**
   * Retorna o ID do usuário autenticado
   */
  getUserId() {
    if (!this.userId && typeof window !== 'undefined') {
      const stored = this.encryptionService.getItem('auth_userId');
      if (stored) this.userId = stored;
    }
    return this.userId;
  }

  /**
   * Retorna o usuário autenticado
   */
  getUser(): User | null {
    if (!this.user && typeof window !== 'undefined') {
      const userId = this.getUserId();
      if (userId) {
        this.searchUsers({ id: Number(userId) }, 0, 1).subscribe({
          next: (res) => {
            const user = res.data?.content?.[0];
            if (user) {
              this.setUser(user);
            }
          }
        })
      }
    }
    return this.user;
  }

  /**
   * Atualiza o usuário autenticado e notifica assinantes
   */
  setUser(user: User): void {
    this.user = user;
    this.userSubject.next(user);
    if ((user as any)?.id) {
      this.encryptionService.setItem('auth_userId', (user as any).id.toString());
    }
    // Não salva mais o user inteiro na sessão
  }

  /**
   * Busca o usuário pelo ID e atualiza o usuário autenticado, se encontrado.
   */
  updateUser(userId: string): void {
    this.searchUsers({ id: Number(userId) }, 0, 1).subscribe({
      next: (res) => {
        const user = res.data?.content?.[0];
        if (user) {
          this.setUser(user);
        } else {
          this.notificationService.showError('Usuário não encontrado para atualização');
        }
      },
      error: (err) => {
        this.notificationService.showError(err.error?.errors || err.error?.data?.message || err.error?.message || err.errors || 'Erro ao atualizar usuário');
      }
    });
  }

  /**
   * Retorna os headers de autenticação para requisições HTTP
   */
  getAuthHeaders(): HttpHeaders {
    if (typeof window === 'undefined') {
      return new HttpHeaders({ 'Content-Type': 'application/json' });
    }
    return new HttpHeaders({
      Authorization: `Bearer ${this.token}`,
      'Content-Type': 'application/json',
    });
  }

  /**
   * Realiza autenticação do usuário
   * @param username Nome de usuário
   * @param password Senha do usuário
   * @returns Observable<User> com os dados do usuário autenticado
   * @throws Error se a autenticação falhar
   */
  authenticate(username: string, password: string): Observable<User> {
    return this.http.post<any>(this.apiUrl, { username, password }).pipe(
      map((response) => {
        if (response.success) {
          if (typeof window !== 'undefined') {
            this.token = response.data.token;
            this.userId = response.data.id;
            this.encryptionService.setItem('auth_token', this.token);
            this.encryptionService.setItem('auth_userId', this.userId);
          }
          this.user = response.data;
          this.userSubject.next(this.user);
          return response.data;
        }
        if (typeof window !== 'undefined') {
          sessionStorage.clear();
        }
        this.token = '';
        this.userId = '';
        throw new Error(response.errors || 'Autenticação falhou');
      }),
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Autenticação falhou';
        return throwError(() => errorMessage);
      })
    );
  }

  /**
   * Realiza logout do usuário e limpa dados da sessão
   */
  logout(): void {
    if (typeof window !== 'undefined') {
      this.encryptionService.removeItem('auth_token');
      this.encryptionService.removeItem('auth_userId');
      sessionStorage.clear();
    }
    this.user = null;
    this.token = '';
    this.userId = '';
    this.userSubject.next(this.user);
    this.router.navigate(['/sign-in']);
  }

  /**
   * Busca usuários com base em critérios de pesquisa - método duplicado devido a referência cruzada
   * @param body Objeto contendo os critérios de pesquisa
   * @param page Página da pesquisa (padrão: 0)
   * @param size Tamanho da página (padrão: 10)
   * @param sort Critério de ordenação (padrão: 'name,asc')
   * @returns Observable com os resultados da pesquisa
   */
  private searchUsers(
    body: any,
    page: number = 0,
    size: number = 10,
    sort: string = 'name,asc'
  ): Observable<any> {
    const headers = this.getAuthHeaders();
    const params = new HttpParams()
      .set('page', page)
      .set('size', size)
      .set('sort', sort);
    return this.http.post<any>(`${environment.apiBaseUrl}${CONST_API_ENDPOINTS.USER_SEARCH}`, body, { headers, params }).pipe(
      catchError((error) => {
        const errorMessage = error.error?.errors || error.error?.data?.message || error.error?.message || error.errors || 'Erro ao buscar usuário';
        return throwError(() => errorMessage);
      })
    );
  }
}
