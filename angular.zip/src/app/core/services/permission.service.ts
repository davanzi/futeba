import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from '../../shared/models/user.model';
import { AuthService } from './auth.service';
import { EncryptionService } from '../../shared/utils/encryption/encryption.service';
import { CONST_API_ENDPOINTS } from '../../shared/constants/api-endpoints.const';
import { CONST_PERMISSIONS } from '../../shared/constants/permissions.const';
import { NotificationService } from '../../shared/services/notification.service';

export interface Permission {
  id: string | null;
  description: string;
  name: string;
}

@Injectable({
  providedIn: 'root',
})
export class PermissionService {
  private listUrl = `${environment.apiBaseUrl}${CONST_API_ENDPOINTS.PERMISSION_LIST}`;

  constructor(
    private http: HttpClient,
    private authService: AuthService,
    private encryptionService: EncryptionService,
    private notificationService: NotificationService
  ) {}

  listPermissions(): Observable<{ data: Permission[]; success: boolean; errors: string }> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<{ data: Permission[]; success: boolean; errors: string }>(this.listUrl, { headers }).pipe(
      catchError((error) => {
        const errorMessage = error.error?.message || 'Erro ao buscar permissões';
        this.notificationService.showError(errorMessage);
        return throwError(() => errorMessage);
      })
    );
  }

  /**
   * Retorna o usuário da sessão ou o fornecido.
   */
  private getCurrentUser(user?: User): User | null {
    if (user) return user;
    return this.authService.getUser();
  }

  /**
   * Verifica se o usuário é MASTER.
   */
  isMaster(user?: User): boolean {
    const u = this.getCurrentUser(user);
    if (!u || !u.profiles) return false;
    return u.profiles.some(p => p.permission?.name?.toUpperCase() === `${CONST_PERMISSIONS.MASTER}`);
  }

  /**
   * Verifica se o usuário possui determinado perfil (por nome).
   */
  hasProfile(profileName: string, user?: User): boolean {
    const u = this.getCurrentUser(user);
    if (!u || !u.profiles) return false;
    return u.profiles.some(p => p.permission?.name?.toUpperCase() === profileName.toUpperCase());
  }

  /**
   * Verifica se o usuário possui fullAccess para determinado perfil (por nome).
   * MASTER sempre retorna true.
   */
  hasFullAccess(profileName: string, user?: User): boolean {
    const u = this.getCurrentUser(user);
    if (!u || !u.profiles) return false;
    if (this.isMaster(u)) return true;
    return u.profiles.some(p => p.permission?.name?.toUpperCase() === profileName.toUpperCase() && p.fullAccess === true);
  }
}
