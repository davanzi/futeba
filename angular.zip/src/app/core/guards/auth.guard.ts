import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { EncryptionService } from '../../shared/utils/encryption/encryption.service';
import { AuthService } from '../services/auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private encryptionService: EncryptionService, private authService: AuthService) {}

  canActivate(): boolean {
    // Garante que só executa no browser
    if (typeof window === 'undefined') {
      return false;
    }
    const userId = this.authService.getUserId();
    const token = this.authService.getToken();

    if (userId && token) {
      return true;
    } else {
      this.router.navigate(['/sign-in']);
      return false;
    }
  }
}
