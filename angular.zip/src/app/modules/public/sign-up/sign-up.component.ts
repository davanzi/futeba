import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PasswordStrengthComponent } from '../../../shared/password-strength/password-strength.component';
import { NgxMaskDirective, provideNgxMask } from 'ngx-mask';
import { UserService } from '../../../shared/services/user.service';
import { Router } from '@angular/router';
import { NotificationService } from '../../../shared/services/notification.service';
import { LoadingService } from '../../../shared/utils/loading/loading.service';
import { EncryptionService } from '../../../shared/utils/encryption/encryption.service';
import { User } from '../../../shared/models/user.model';

@Component({
  selector: 'app-sign-up',
  imports: [
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    RouterModule,
    PasswordStrengthComponent,
    NgxMaskDirective
  ],
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss'],
  providers: [provideNgxMask()]
})
export class SignUpComponent {
  hidePassword: boolean = true;
  hideRepeatPassword: boolean = true;
  password: string = '';
  repeatPassword: string = '';
  mismatchMessage: string = '';
  name: string = '';
  email: string = '';
  cpf: string = '';

  constructor(
    private userService: UserService,
    private router: Router,
    private notificationService: NotificationService, // Inject NotificationService directly
    private loadingService: LoadingService, // Inject LoadingService
    private encryptionService: EncryptionService // Inject EncryptionService
  ) { }

  togglePasswordVisibility(event: Event, field: 'password' | 'repeatPassword'): void {
    event.preventDefault();
    if (field === 'password') {
      this.hidePassword = !this.hidePassword;
    } else {
      this.hideRepeatPassword = !this.hideRepeatPassword;
    }
  }

  validatePasswordMatch(): void {
    if (this.repeatPassword.length > 0 && this.password !== this.repeatPassword) {
      this.mismatchMessage = 'As senhas não coincidem';
    } else {
      this.mismatchMessage = '';
    }
  }

  register(): void {
    if (!this.name || !this.email || !this.cpf || !this.password || !this.repeatPassword) {
      this.notificationService.showError('Por favor, preencha todos os campos.');
      return;
    }

    if (this.password !== this.repeatPassword) {
      this.notificationService.showError('As senhas não coincidem.');
      return;
    }

    const user: User = {
      id: null,
      name: this.name,
      email: this.email,
      cpf: this.cpf,
      password: this.encryptionService.encrypt(this.password),
      profileImage: '',
      profiles: [],
      active: true,
      lastLogin: '',
      temporaryPassword: false,
      token: ''
    };

    this.loadingService.show();
    this.userService.register(user).subscribe({
      next: () => {
        this.notificationService.showInfo('Cadastro realizado com sucesso!');
        this.router.navigate(['/sign-in']);
      },
      error: (err) => {
        this.notificationService.showError(err.toString());
      }
    }).add(() => {
      this.loadingService.hide();
    });
  }
}
