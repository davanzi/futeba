import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgxMaskDirective, provideNgxMask } from 'ngx-mask';
import { UserService } from '../../../shared/services/user.service';
import { Router } from '@angular/router';
import { NotificationService } from '../../../shared/services/notification.service';
import { LoadingService } from '../../../shared/utils/loading/loading.service';

@Component({
  selector: 'app-reset-password',
  imports: [
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    FormsModule,
    RouterModule,
    NgxMaskDirective
  ],
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
  providers: [provideNgxMask()]
})
export class ResetPasswordComponent {
  cpf: string = '';
  email: string = '';
  maskedEmail: string = '';
  isEmailInputEnabled: boolean = false;
  isSubmitEnabled: boolean = false;
  isLoading: boolean = false;

  constructor(
    private userService: UserService,
    private router: Router,
    private notificationService: NotificationService,
    private loadingService: LoadingService
  ) { }

  enableSubmit(): void {
    this.isSubmitEnabled = !!this.email;
  }

  fetchMaskedEmail(): void {
    if (this.cpf) {
      this.loadingService.show();
      this.userService.getMaskedEmail(this.cpf).subscribe({
        next: (response) => {
          if (response.success) {
            this.maskedEmail = response.data;
            this.isEmailInputEnabled = true;
          } else {
            this.notificationService.showError(response.errors);
          }
        },
        error: (err) => {
          this.notificationService.showError(err.toString());
        }
      }).add(() => {
        this.loadingService.hide();
      });
    }
  }

  resetPassword(): void {
    if (this.cpf && this.email) {
      this.loadingService.show();
      const payload = { cpf: this.cpf, email: this.email };
      this.userService.resetPasswordPublic(payload).subscribe({
        next: (response) => {
          if (response.success) {
            this.notificationService.showInfo('Senha recuperada com sucesso!');
            this.router.navigate(['/sign-in']);
          } else {
            this.notificationService.showError(response.errors);
          }
        },
        error: (err) => {
          this.notificationService.showError(err.toString());
        }
      }).add(() => {
        this.loadingService.hide();
      });
    }
  }
}
