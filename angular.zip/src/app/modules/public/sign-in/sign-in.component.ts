import { Component, HostListener } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle'; // Corrigir o caminho do MatSlideToggleModule
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgxMaskDirective, provideNgxMask } from 'ngx-mask';
import { AuthService } from '../../../core/services/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common'; // Import CommonModule
import { ToastrModule } from 'ngx-toastr';
import { NotificationService } from '../../../shared/services/notification.service';
import { LoadingService } from '../../../shared/utils/loading/loading.service';
import { SessionTimeoutService } from '../../../core/services/session-timeout.service'; // Import SessionTimeoutService
import { VersionComponent } from '../../../shared/utils/version/version.component';
import { EncryptionService } from '../../../shared/utils/encryption/encryption.service';
import { CONST_ROUTES } from '../../../shared/constants/routes.const';

@Component({
  selector: 'app-sign-in',
  imports: [
    CommonModule, // Add CommonModule here
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatSlideToggleModule,
    FormsModule,
    RouterModule,
    NgxMaskDirective,
    ToastrModule, // Importar apenas ToastrModule
    VersionComponent
  ],
  templateUrl: './sign-in.component.html',
  styleUrl: './sign-in.component.scss',
  providers: [provideNgxMask()]
})
export class SignInComponent {
  hidePassword: boolean = true;
  saveCredentials: boolean = false;
  username: string = '';
  password: string = '';
  errorMessage: string = '';
  count = 0;

  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService, // Inject NotificationService directly
    private loadingService: LoadingService, // Inject LoadingService
    private sessionTimeout: SessionTimeoutService, // Inject SessionTimeoutService
    private encryptionService: EncryptionService // Inject EncryptionService
  ) { }

  @HostListener('document:keydown.enter', ['$event'])
  onEnterKeyPress(event: KeyboardEvent): void {
    if (this.username && this.password) {
      this.login();
    }
  }

  togglePasswordVisibility(event: Event): void {
    event.preventDefault(); // Prevent default click behavior
    this.hidePassword = !this.hidePassword; // Toggle password visibility
  }

  login(): void {
    if (!this.username || !this.password) {
      this.notificationService.showError('Por favor, preencha todos os campos.');
      return;
    }

    this.loadingService.show(); // Show loading
    this.count++;
    console.log('Senha: ' + this.encryptionService.encrypt(this.password));
    this.authService.authenticate(this.username, this.encryptionService.encrypt(this.password)).subscribe({
      next: (user) => {
        this.sessionTimeout.startMonitoring();
        // Redireciona para update-password se necessário, senão para home
        if (user && user.temporaryPassword) {
          this.router.navigate([CONST_ROUTES.UPDATE_PASSWORD.route]);
        } else {
          this.router.navigate([CONST_ROUTES.HOME.route]);
        }
      },
      error: (err) => {
        this.loadingService.hide();
        this.notificationService.showError(err);
      },
      complete: () => {
        setTimeout(() => {
          this.loadingService.hide();
        }, 1000);
      }
    });
  }
}
