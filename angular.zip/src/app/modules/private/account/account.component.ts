import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserService } from '../../../shared/services/user.service';
import { NotificationService } from '../../../shared/services/notification.service';
import { User } from '../../../shared/models/user.model';
import { Router } from '@angular/router';
import { PasswordStrengthComponent } from '../../../shared/password-strength/password-strength.component';
import { NgxMaskDirective, provideNgxMask } from 'ngx-mask';
import { AuthService } from '../../../core/services/auth.service';
import { EncryptionService } from '../../../shared/utils/encryption/encryption.service';
import { MediaService } from '../../../shared/services/media.service';
import { environment } from '../../../../environments/environment';
import { CONST_ROUTES } from '../../../shared/constants/routes.const';
import { LoadingService } from '../../../shared/utils/loading/loading.service';

@Component({
  selector: 'app-account',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    ReactiveFormsModule,
    PasswordStrengthComponent,
    NgxMaskDirective,
    FormsModule
  ],
  providers: [provideNgxMask()],
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit {
  userForm!: FormGroup;
  loading = false;
  profileImageBase64: string = '';
  profileImagePreview: string = '';
  profileImageName: string = '';
  showPasswordFields = false;
  hidePassword = true;
  hideRepeatPassword = true;
  mismatchMessage: string = '';
  currentUser: User | null = null;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private notification: NotificationService,
    private loadingService: LoadingService,
    private router: Router,
    private authService: AuthService,
    private encryptionService: EncryptionService,
    private mediaService: MediaService
  ) {
    // Always initialize the form with all controls, cpf and lastLogin disabled
    this.userForm = this.fb.group({
      id: [''],
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      cpf: [{ value: '', disabled: true }, [Validators.required, Validators.pattern(/\d{3}\.\d{3}\.\d{3}-\d{2}/)]],
      lastLogin: [{ value: '', disabled: true }],
      profileImage: [''],
      password: [''],
      repeatPassword: ['']
    });
  }

  ngOnInit(): void {
    const user = this.authService.getUser();
    if (user) {
      this.currentUser = user;
      if (user.profileImage) {
        this.profileImagePreview = `${environment.apiMultimidiaUrl}${user.profileImage}`;
      } else {
        this.profileImagePreview = '';
      }
      let lastLogin = user.lastLogin;
      if (lastLogin) {
        const d = new Date(lastLogin);
        lastLogin = d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
          ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', hour12: false });
      }
      // Patch values, nunca reatribua o form
      this.userForm.patchValue({
        id: user.id,
        name: user.name,
        email: user.email,
        cpf: String(user.cpf ?? ''),
        lastLogin: lastLogin,
        profileImage: user.profileImage
      });
    } else {
      this.userForm.reset({
        id: '',
        name: '',
        email: '',
        cpf: '',
        lastLogin: '',
        profileImage: '',
        password: '',
        repeatPassword: ''
      });
      this.profileImagePreview = '';
      this.currentUser = null;
    }
  }

  triggerFileInput() {
    const fileInput = document.getElementById('profileImageInput');
    if (fileInput) (fileInput as HTMLInputElement).click();
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.loading = true;
      this.loadingService.show();
      this.mediaService.uploadImage(file).subscribe({
        next: (res) => {
          if (res && res.data && res.data.image) {
            this.profileImageName = res.data.image;
            this.profileImagePreview = `${environment.apiMultimidiaUrl}${res.data.image}`;
          }
        },
        error: () => {
          this.notification.showError('Erro ao fazer upload da imagem.');
        }
      }).add(() => {
        this.loadingService.hide();
        this.loading = false;
      });
    }
  }

  enablePasswordChange(): void {
    this.showPasswordFields = true;
    this.userForm.patchValue({ password: '', repeatPassword: '' });
    this.hidePassword = true;
    this.hideRepeatPassword = true;
  }

  cancelPasswordChange(): void {
    this.showPasswordFields = false;
    this.userForm.patchValue({ password: '', repeatPassword: '' });
    this.mismatchMessage = '';
    this.hidePassword = true;
    this.hideRepeatPassword = true;
  }

  togglePasswordVisibility(field: 'password' | 'repeatPassword'): void {
    if (field === 'password') {
      this.hidePassword = !this.hidePassword;
    } else {
      this.hideRepeatPassword = !this.hideRepeatPassword;
    }
  }

  validatePasswordMatch(): void {
    const password = this.userForm.get('password')?.value;
    const repeatPassword = this.userForm.get('repeatPassword')?.value;
    if (repeatPassword && password !== repeatPassword) {
      this.mismatchMessage = 'As senhas não coincidem';
    } else {
      this.mismatchMessage = '';
    }
  }

  onSubmit(): void {
    if (this.userForm.invalid) return;
    let updateData: any = {
      id: this.userForm.get('id')?.value,
      name: this.userForm.get('name')?.value,
      email: this.userForm.get('email')?.value,
      // Só envia profileImage se foi alterada, senão mantém o valor anterior
      profileImage: this.profileImageName || this.userForm.get('profileImage')?.value || undefined
    };
    if (this.showPasswordFields) {
      const password = this.userForm.get('password')?.value;
      const repeatPassword = this.userForm.get('repeatPassword')?.value;
      if (!password || !repeatPassword) {
        this.notification.showError('Preencha a nova senha e a repetição.');
        return;
      }
      if (password !== repeatPassword) {
        this.notification.showError('As senhas não coincidem.');
        return;
      }
      let score = 0;
      if (password.length >= 10) score++;
      if (/[A-Z]/.test(password)) score++;
      if (/[a-z]/.test(password)) score++;
      if (/[0-9]/.test(password)) score++;
      if (/[^A-Za-z0-9]/.test(password)) score++;
      if (score < 5) {
        this.notification.showError('A senha deve conter no mínimo 10 caracteres, incluindo letras maiúsculas, minúsculas, números e caracteres especiais.');
        return;
      }
      updateData.password = this.encryptionService.encrypt(password);
    }
    this.loading = true;
    this.loadingService.show();
    this.userService.updateUser(updateData).subscribe({
      next: () => {
        this.notification.showInfo('Dados atualizados com sucesso!');
        const updatedUser: User = {
          id: this.userForm.get('id')?.value,
          name: this.userForm.get('name')?.value,
          email: this.userForm.get('email')?.value,
          cpf: this.userForm.get('cpf')?.value,
          lastLogin: this.userForm.get('lastLogin')?.value,
          profileImage: updateData.profileImage || '',
          profiles: this.currentUser?.profiles || [],
          active: this.currentUser?.active ?? true,
          temporaryPassword: this.currentUser?.temporaryPassword ?? false,
          token: this.currentUser?.token || ''
        };
        this.authService.updateUser(updatedUser.id ?? '');
        this.userForm.patchValue({ password: '', repeatPassword: '' });
        this.showPasswordFields = false;
        this.router.navigate([CONST_ROUTES.HOME.route]);
      },
      error: (err: any) => {
        this.notification.showError(err.toString());
      }
    }).add(() => {
      this.loadingService.hide();
      this.loading = false;
    });
  }
}
