import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { UserService } from '../../../../shared/services/user.service';
import { User } from '../../../../shared/models/user.model';
import { PageEvent } from '@angular/material/paginator';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { NgxMaskDirective, provideNgxMask } from 'ngx-mask';
import { NotificationService } from '../../../../shared/services/notification.service';
import { UserProfileDialogComponent } from '../user-profile/user-profile-dialog.component';
import { UserResetPasswordDialogComponent } from '../user-reset-password/user-reset-password-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { PermissionService } from '../../../../core/services/permission.service';
import { EncryptionService } from '../../../../shared/utils/encryption/encryption.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LoadingService } from '../../../../shared/utils/loading/loading.service';
import { environment } from '../../../../../environments/environment';
import { AuthService } from '../../../../core/services/auth.service';
import { PaginationComponent } from '../../../../shared/components/pagination/pagination.component';
import { CONST_PERMISSIONS } from '../../../../shared/constants/permissions.const';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatIconModule,
    MatCardModule,
    MatSlideToggleModule,
    MatCheckboxModule, // necessário para mat-checkbox
    PaginationComponent, // componente de paginação reutilizável
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    NgxMaskDirective,
    UserProfileDialogComponent,
    UserResetPasswordDialogComponent
  ],
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss'],
  providers: [provideNgxMask()]
})
export class UserComponent implements OnInit {
  displayedColumns: string[] = ['profileImage', 'active', 'name', 'cpf', 'email', 'lastLogin', 'temporaryPassword', 'actions'];
  dataSource: User[] = [];
  totalElements = 0;
  pageSize = 10;
  pageIndex = 0;
  sortField = 'name';
  sortOrder = 'asc';
  loading = false;
  loggedUserId: string | null = null;
  filter = { name: '', email: '', cpf: '', active: '' };
  apiBaseUrl = environment.apiBaseUrl;
  apiMultimidiaUrl = environment.apiMultimidiaUrl;

  constructor(
    private userService: UserService,
    @Inject(PLATFORM_ID) private platformId: Object,
    private dialog: MatDialog,
    private notification: NotificationService,
    private permissionService: PermissionService,
    private encryptionService: EncryptionService,
    private router: Router,
    private route: ActivatedRoute,
    private loadingService: LoadingService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.loggedUserId= this.authService.getUserId();
    } else {
      this.loggedUserId = null;
    }
    this.loadUsers();
  }

  loadUsers(page: number = 0, size: number = this.pageSize, sort: string = `${this.sortField},${this.sortOrder}`): void {
    this.loading = true;
    this.loadingService.show();

    const body: any = {
      id: null,
      password: '',
      name: this.filter.name,
      email: this.filter.email,
      cpf: this.filter.cpf,
    };

    if (this.filter.active !== '') {
      body.active = this.filter.active === 'true';
    }

    this.userService.searchUsers(body, page, size, sort).subscribe({
      next: (res) => {
        // Formata o CPF e limpa o base64 da imagem
        this.dataSource = res.data.content.map((user: User) => ({
          ...user,
          cpf: user.cpf ? user.cpf.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4') : '',
          profileImage: user.profileImage || ''
        }));
        this.dataSource = [...this.dataSource]; // Força atualização da tabela
        this.totalElements = res.data.totalElements;
        this.pageSize = res.data.size;
        this.pageIndex = res.data.number;
      },
      error: () => {
        this.notification.showError('Erro ao carregar usuários');
      }
    }).add(() => {
      this.loading = false;
      this.loadingService.hide();
    });
  }

  onPageChange(event: PageEvent): void {
    this.loadUsers(event.pageIndex, event.pageSize, `${this.sortField},${this.sortOrder}`);
  }

  onSortChange(field: string): void {
    this.sortField = field;
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    this.loadUsers(this.pageIndex, this.pageSize, `${this.sortField},${this.sortOrder}`);
  }

  onToggleStatus(user: User): void {
    if (!user.id) return;
    this.loadingService.show();
    this.userService.changeStatus(user.id).subscribe({
      next: () => {
        user.active = !user.active;
        this.notification.showInfo(`Usuário ${user.active ? 'ativado' : 'desativado'} com sucesso!`);
      },
      error: () => {
        this.notification.showError(`Erro ao ${user.active ? 'desativar' : 'ativar'} usuário.`);
      }
    }).add(() => {
      this.loadingService.hide();
    });
  }

  onSearch(): void {
    this.pageIndex = 0;
    this.loadUsers(0, this.pageSize, `${this.sortField},${this.sortOrder}`);
  }

  onClearFilters(): void {
    this.filter = { name: '', email: '', cpf: '', active: '' };
    this.onSearch();
  }

  onEditUser(user: User): void {
    if (!user) {
      this.notification.showError('Usuário inválido para edição.');
      return;
    }
    this.router.navigate(['../user-register'], { relativeTo: this.route, queryParams: { id: user.id } });
  }

  onEditProfile(user: User): void {
    if (!user) {
      this.notification.showError('Usuário inválido para edição de perfil.');
      return;
    }
    const dialogRef = this.dialog.open(UserProfileDialogComponent, {
      width: '900px',
      data: { user: { ...user } },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && typeof result === 'object' && result.id) {
        // Atualiza apenas o usuário editado na tabela
        const idx = this.dataSource.findIndex(u => u.id === result.id);
        if (idx !== -1) {
          this.dataSource[idx] = { ...this.dataSource[idx], ...result };
          this.dataSource = [...this.dataSource]; // Força atualização da tabela
        }
        this.notification.showInfo('Perfil do usuário atualizado com sucesso!');
      } else if (result) {
        this.loadingService.show();
        this.loadUsers(this.pageIndex, this.pageSize, `${this.sortField},${this.sortOrder}`);
        this.loadingService.hide();
      }
    });
  }

  resetPassword(user: User): void {
    const dialogRef = this.dialog.open(UserResetPasswordDialogComponent, {
      width: '350px',
      data: { user }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadingService.show();
        this.userService.resetPassword(user.email, user.cpf).subscribe({
          next: () => {
            this.notification.showInfo('Senha resetada com sucesso!');
          },
          error: (err) => {
            this.notification.showError(err.toString());
          }
        }).add(() => {
          this.loadingService.hide();
        });
      }
    });
  }

  onRegister(): void {
    this.router.navigate(['../user-register'], { relativeTo: this.route });
  }

  onViewUser(user: User): void {
    if (!user) {
      this.notification.showError('Usuário inválido para visualização.');
      return;
    }
    this.router.navigate(['../user-register'], { relativeTo: this.route, queryParams: { id: user.id, view: true } });
  }

  get hasUserFullAccess(): boolean {
    return this.permissionService.hasFullAccess(`${CONST_PERMISSIONS.USER}`);
  }
}
