import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-user-reset-password-dialog',
  template: `
    <mat-dialog-content>
      Tem certeza que deseja resetar a senha do usuário?
    </mat-dialog-content>
    <mat-dialog-actions>
      <button mat-raised-button (click)="onNo()">Não</button>
      <button mat-raised-button color="primary" (click)="onYes()">Sim</button>
    </mat-dialog-actions>
  `,
  imports: [MatDialogModule, MatButtonModule],
})
export class UserResetPasswordDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<UserResetPasswordDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  onNo(): void {
    this.dialogRef.close(false);
  }

  onYes(): void {
    this.dialogRef.close(true);
  }
}
