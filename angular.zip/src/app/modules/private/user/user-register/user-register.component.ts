import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../../../shared/services/user.service';
import { AuthService } from '../../../../core/services/auth.service';
import { NotificationService } from '../../../../shared/services/notification.service';
import { EncryptionService } from '../../../../shared/utils/encryption/encryption.service';
import { LoadingService } from '../../../../shared/utils/loading/loading.service';
import { MediaService } from '../../../../shared/services/media.service';
import { PermissionService } from '../../../../core/services/permission.service';
import { environment } from '../../../../../environments/environment';
import { CONST_PERMISSIONS } from '../../../../shared/constants/permissions.const';
import { CONST_ROUTES } from '../../../../shared/constants/routes.const';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-user-register',
  standalone: true,
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    RouterModule
  ]
})
export class UserRegisterComponent {
  user = {
    id: null,
    name: '',
    email: '',
    cpf: '',
    profileImage: '',
    active: true
  };
  profileImagePreview: string = '';
  isEditMode: boolean = false;
  isViewMode: boolean = false;
  loading = false;
  error = '';
  hasFullAccessUser: boolean = true;

  constructor(
    private userService: UserService,
    private authService: AuthService,
    private notification: NotificationService,
    private router: Router,
    private encryptionService: EncryptionService,
    private loadingService: LoadingService,
    private mediaService: MediaService,
    private route: ActivatedRoute,
    private permissionService: PermissionService,
    private titleService: Title
  ) {
    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.loadUser(params['id']);
      } else {
        this.isEditMode = false;
        this.user = {
          id: null,
          name: '',
          email: '',
          cpf: '',
          profileImage: '',
          active: true
        };
        this.profileImagePreview = '';
      }
      this.isViewMode = params['view'] === 'true';
      if (this.isViewMode) {
        this.titleService.setTitle('Visualizar Usuário');
      } else if (this.isEditMode) {
        this.titleService.setTitle('Editar Usuário');
      } else {
        this.titleService.setTitle('Cadastrar Usuário');
      }
    });
    this.hasFullAccessUser = this.permissionService.hasFullAccess(`${CONST_PERMISSIONS.USER}`);
  }

  loadUser(id: string) {
    this.loading = true;
    this.loadingService.show();
    this.userService.searchUsers({ id: Number(id) }, 0, 1).subscribe({
      next: (res) => {
        const user = res.data.content[0];
        this.user = {
          id: user.id,
          name: user.name,
          email: user.email,
          cpf: user.cpf,
          profileImage: user.profileImage,
          active: user.active
        };
        this.profileImagePreview = user.profileImage ? `${environment.apiMultimidiaUrl}${user.profileImage}` : '';
      },
      error: () => {
        this.notification.showError('Erro ao carregar usuário para edição.');
      }
    }).add(() => {
      this.loading = false;
      this.loadingService.hide();
    });
  }

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (!file) return;
    this.loading = true;
    this.loadingService.show();
    this.mediaService.uploadImage(file).subscribe({
      next: (res) => {
        if (res && res.data && res.data.image) {
          this.user.profileImage = res.data.image;
          this.profileImagePreview = `${environment.apiMultimidiaUrl}${res.data.image}`;
        }
      },
      error: () => {
        this.notification.showError('Erro ao fazer upload da imagem.');
      }
    }).add(() => {
      this.loading = false;
      this.loadingService.hide();
    });
  }

  onSubmit() {
    this.loading = true;
    this.loadingService.show();
    this.error = '';
    const payload: any = {
      id: this.isEditMode ? this.user.id : null,
      name: this.user.name,
      email: this.user.email,
      cpf: this.user.cpf,
      profileImage: this.user.profileImage || '',
      active: true
    };
    const request$ = this.isEditMode
      ? this.userService.updateUser(payload)
      : this.userService.register(payload);
    request$.subscribe({
      next: () => {
        this.notification.showInfo(this.isEditMode ? 'Usuário atualizado com sucesso!' : 'Usuário cadastrado e senha enviada com sucesso!');
        this.router.navigate([CONST_ROUTES.USER.route]);
      },
      error: (err) => {
        this.notification.showError('Erro ao salvar usuário: ' + err.toString());
      }
    }).add(() => {
      this.loading = false;
      this.loadingService.hide();
    });
  }

  onCancel() {
    history.back();
  }

  onClear() {
    this.user = {
      id: null,
      name: '',
      email: '',
      cpf: '',
      profileImage: '',
      active: true
    };
    this.profileImagePreview = '';
  }
}
