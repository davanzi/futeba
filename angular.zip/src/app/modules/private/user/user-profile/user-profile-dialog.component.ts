import { Component, Inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef, MatDialogModule, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FormsModule } from '@angular/forms';
import { PermissionService, Permission } from '../../../../core/services/permission.service';
import { UserService } from '../../../../shared/services/user.service';
import { CONST_PERMISSIONS } from '../../../../shared/constants/permissions.const';
import { LoadingService } from '../../../../shared/utils/loading/loading.service';
import { NotificationService } from '../../../../shared/services/notification.service';

function sortPermissionsCustom<T extends { name: string; description: string }>(items: T[]): T[] {
  // HOME primeiro, depois MASTER, depois ordem alfabética por description
  return items.slice().sort((a, b) => {
    if (a.name === CONST_PERMISSIONS.HOME) return -1;
    if (b.name === CONST_PERMISSIONS.HOME) return 1;
    if (a.name === 'MASTER') return b.name === CONST_PERMISSIONS.HOME ? 1 : -1;
    if (b.name === 'MASTER') return a.name === CONST_PERMISSIONS.HOME ? -1 : 1;
    return a.description.localeCompare(b.description, 'pt-BR', { sensitivity: 'base' });
  });
}

@Component({
  selector: 'app-user-profile-dialog',
  templateUrl: './user-profile-dialog.component.html',
  styleUrls: ['./user-profile-dialog.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatCheckboxModule,
    FormsModule,
  ]
})
export class UserProfileDialogComponent implements OnInit {
  availableItems: Permission[] = [];
  selectedItems: { id: number; description: string; name: string; fullAccess: boolean; disabled?: boolean }[] = [];
  selectedAvailable: Permission | null = null;
  selectedSelected: { id: number; description: string; name: string; fullAccess: boolean; disabled?: boolean } | null = null;
  userId: number | null = null;

  constructor(
    public dialogRef: MatDialogRef<UserProfileDialogComponent>,
    private permissionService: PermissionService,
    private userService: UserService,
    private loadingService: LoadingService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    if (data && data.user) {
      this.userId = Number(data.user.id);
    }
  }

  ngOnInit(): void {
    setTimeout(() => {
      this.loadingService.show();
    });
    this.permissionService.listPermissions().subscribe({
      next: (res) => {
        const allPermissions = res.data || [];
        const userProfiles = this.data.user?.profiles || [];
        this.selectedItems = userProfiles.map((profile: any) => {
          const isMaster = profile.permission.name === 'MASTER';
          return {
            id: Number(profile.permission.id),
            description: profile.permission.description,
            name: profile.permission.name,
            fullAccess: isMaster ? true : profile.fullAccess === true,
            disabled: isMaster ? true : false
          };
        });
        // Garante que 'home' esteja sempre presente, fullAccess true, e não duplicado
        const homePermission = allPermissions.find((perm: Permission) => perm.name === `${CONST_PERMISSIONS.HOME}`);
        if (homePermission) {
          const alreadyInSelected = this.selectedItems.some(sel => sel.name === `${CONST_PERMISSIONS.HOME}`);
          if (!alreadyInSelected) {
            this.selectedItems.unshift({
              id: Number(homePermission.id),
              description: homePermission.description,
              name: homePermission.name,
              fullAccess: true,
              disabled: true
            });
          } else {
            this.selectedItems = this.selectedItems
              .map(sel => sel.name === `${CONST_PERMISSIONS.HOME}` ? { ...sel, fullAccess: true, disabled: true } : sel)
              .sort((a, b) => (a.name === `${CONST_PERMISSIONS.HOME}` ? -1 : b.name === `${CONST_PERMISSIONS.HOME}` ? 1 : 0));
          }
        }
        // Garante que MASTER está sempre com fullAccess true e disabled true
        this.selectedItems = this.selectedItems.map(sel =>
          sel.name === 'MASTER' ? { ...sel, fullAccess: true, disabled: true } : sel
        );
        this.availableItems = allPermissions.filter((perm: Permission) =>
          !this.selectedItems.some(sel => sel.id === Number(perm.id))
        );
        this.selectedItems = sortPermissionsCustom(this.selectedItems);
        this.availableItems = sortPermissionsCustom(this.availableItems);
        setTimeout(() => {
          this.loadingService.hide();
        });
      },
      error: () => {
        setTimeout(() => {
          this.loadingService.hide();
        });
      }
    });
  }

  selectAvailable(item: Permission) {
    this.selectedAvailable = item;
    this.selectedSelected = null;
  }

  selectSelected(item: { id: number; description: string; name: string; fullAccess: boolean }) {
    this.selectedSelected = item;
    this.selectedAvailable = null;
  }

  moveToSelected(item: Permission) {
    const isMaster = item.name === 'MASTER';
    this.selectedItems.push({ ...item, id: Number(item.id), fullAccess: isMaster ? true : false, disabled: isMaster });
    this.availableItems = this.availableItems.filter(i => Number(i.id) !== Number(item.id));

    // Regra: se adicionar MASTER, move todos os outros (exceto HOME) para a esquerda
    if (isMaster) {
      // Move todos os selecionados (exceto HOME e MASTER) para disponíveis
      const toMoveLeft = this.selectedItems.filter(i => i.name !== 'MASTER' && i.name !== CONST_PERMISSIONS.HOME);
      toMoveLeft.forEach(perm => {
        this.availableItems.push({ id: String(perm.id), description: perm.description, name: perm.name });
      });
      // Mantém apenas HOME e MASTER na direita
      this.selectedItems = this.selectedItems.filter(i => i.name === 'MASTER' || i.name === CONST_PERMISSIONS.HOME);
    }

    this.selectedItems = sortPermissionsCustom(this.selectedItems);
    this.availableItems = sortPermissionsCustom(this.availableItems);
    if (this.selectedAvailable === item) {
      this.selectedAvailable = null;
    }
  }

  moveToAvailable(item: { id: number; description: string; name: string; fullAccess: boolean }) {
    // Bloqueia remoção do item 'home'
    if (item.name === `${CONST_PERMISSIONS.HOME}`) return;
    this.availableItems.push({ id: String(item.id), description: item.description, name: item.name });
    this.selectedItems = this.selectedItems.filter(i => i.id !== item.id);
    this.selectedItems = sortPermissionsCustom(this.selectedItems);
    this.availableItems = sortPermissionsCustom(this.availableItems);
    if (this.selectedSelected === item) this.selectedSelected = null;
  }

  addSelected() {
    if (this.selectedAvailable) {
      this.moveToSelected(this.selectedAvailable);
      this.selectedAvailable = null;
    }
  }

  removeSelected() {
    if (this.selectedSelected) {
      this.moveToAvailable(this.selectedSelected);
    }
  }

  onCancel() {
    this.dialogRef.close();
  }

  onSave() {
    if (!this.userId) return;
    // Garante que 'home' está presente e fullAccess true
    this.selectedItems = this.selectedItems.map(item =>
      item.name === `${CONST_PERMISSIONS.HOME}` ? { ...item, fullAccess: true } : item
    );
    const profiles = this.selectedItems.map(item => ({
      idPermission: item.id,
      fullAccess: item.fullAccess
    }));
    this.loadingService.show();
    this.userService.updateUserProfile({ idUser: this.userId, profiles }).subscribe({
      next: (response) => {
        if (response && response.data) {
          this.dialogRef.close(response.data);
        } else {
          this.dialogRef.close(true);
        }
      },
      error: (err) => {
        this.notificationService.showError(err.toString());
      }
    }).add(() => {
      this.loadingService.hide();
    });
  }
}
