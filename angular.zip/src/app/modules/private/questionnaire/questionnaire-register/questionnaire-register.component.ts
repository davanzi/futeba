import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CdkDragDrop, DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire.service';
import { QuestionService } from 'src/app/shared/services/question.service';
import { QuestionnaireRegisterRequest, Questionnaire } from 'src/app/shared/models/questionnaire.model';
import { Question } from 'src/app/shared/models/question.model';
import { CONST_PERMISSIONS } from 'src/app/shared/constants/permissions.const';
import { PermissionService } from 'src/app/core/services/permission.service';
import { QuestionCategory } from 'src/app/shared/models/question-category.model';
import { DepartmentService } from 'src/app/shared/services/department.service';
import { Department } from 'src/app/shared/models/department.model';
import { QuestionCategoryService } from 'src/app/shared/services/question-category.service';

@Component({
  selector: 'app-questionnaire-register',
  standalone: true,
  templateUrl: './questionnaire-register.component.html',
  styleUrls: ['./questionnaire-register.component.scss'],
  imports: [
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatSelectModule,
    RouterModule,
    FormsModule,
    DragDropModule
  ]
})
export class QuestionnaireRegisterComponent implements OnInit {
  questionnaire: QuestionnaireRegisterRequest = {
    id: null,
    name: '',
    questionIds: [],
    template: true,
    active: true,
    department: { id: null, name: '', active: true }
  };
  questions: Question[] = [];
  selectedQuestions: Question[] = [];
  filter = { title: '', categoryId: '' };
  selectedFilter = { title: '', categoryId: '' };
  isEditMode = false;
  isViewMode = false;
  loading = false;
  categories: QuestionCategory[] = [];
  departments: Department[] = [];
  selectedDepartmentId: string | null = null;

  private questionnaireService = inject(QuestionnaireService);
  private questionService = inject(QuestionService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private permissionService = inject(PermissionService);
  private departmentService = inject(DepartmentService);
  private questionCategoryService = inject(QuestionCategoryService);

  ngOnInit(): void {
    this.departmentService.searchDepartments({ name: '', active: true, id: null }, 0, 100).subscribe({
      next: (res) => {
        this.departments = (res?.data?.content && Array.isArray(res.data.content)) ? res.data.content : [];
        // Se já existe um departamento no questionário, sincroniza o id auxiliar
        if (this.questionnaire.department && this.questionnaire.department.id) {
          this.selectedDepartmentId = this.questionnaire.department.id;
        }
      },
      error: () => {
        this.departments = [];
      }
    });
    this.questionCategoryService.searchQuestionCategories({}, 0, 100).subscribe({
      next: (res: any) => {
        this.categories = (res?.data?.content && Array.isArray(res.data.content)) ? res.data.content : [];
      },
      error: () => {
        this.categories = [];
      }
    });
    this.loadQuestions();
    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.loading = true;
        // Busca pelo método questionnaire/search
        const body = { id: params['id'], name: '', questionIds: [], template: true, active: undefined, department: undefined };
        this.questionnaireService.searchQuestionnaires(body, 0, 1).subscribe({
          next: (res) => {
            const found = res.data.content && res.data.content.length > 0 ? res.data.content[0] : null;
            if (found) {
              this.questionnaire = {
                id: found.id,
                name: found.name,
                questionIds: found.questions.map((q: any) => q.id!),
                template: found.template,
                active: found.active,
                department: found.department || { id: null, name: '', active: true }
              };
              this.selectedQuestions = found.questions;
              this.selectedDepartmentId = this.questionnaire.department?.id || null;
            }
            this.loading = false;
          },
          error: () => { this.loading = false; }
        });
      }
      this.isViewMode = params['view'] === 'true';
    });
  }

  loadQuestions(): void {
    this.questionService.searchQuestions({ template: true }, 0, 100).subscribe({
      next: (res) => {
        this.questions = res.data.content;
      }
    });
  }

  filteredQuestions(): Question[] {
    return this.questions.filter(q =>
      (this.filter.categoryId ? q.questionCategory?.id === this.filter.categoryId : true) &&
      q.title.toLowerCase().includes(this.filter.title.toLowerCase()) &&
      !this.selectedQuestions.find(sq => sq.id === q.id)
    );
  }

  addQuestion(q: Question): void {
    if (!this.selectedQuestions.find(sq => sq.id === q.id)) {
      this.selectedQuestions.push(q);
    }
  }

  removeQuestion(q: Question): void {
    this.selectedQuestions = this.selectedQuestions.filter(sq => sq.id !== q.id);
  }

  drop(event: CdkDragDrop<Question[]>) {
    moveItemInArray(this.selectedQuestions, event.previousIndex, event.currentIndex);
  }

  onSubmit(): void {
    if (this.isViewMode) return;
    this.loading = true;
    this.questionnaire.questionIds = this.selectedQuestions.map(q => q.id!);
    // Seta o departamento selecionado no payload
    if (this.selectedDepartmentId) {
      const selectedDept = this.departments.find(d => d.id === this.selectedDepartmentId);
      this.questionnaire.department = selectedDept ? { ...selectedDept } : undefined;
    } else {
      this.questionnaire.department = undefined;
    }
    this.questionnaireService.registerOrUpdate(this.questionnaire).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigate(['../questionnaire'], { relativeTo: this.route });
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  onClear(): void {
    if (this.isViewMode) return;
    this.questionnaire = { id: null, name: '', questionIds: [], template: true, active: true, department: { id: null, name: '', active: true } };
    this.selectedQuestions = [];
    this.selectedDepartmentId = null;
  }

  onClearQuestionFilter(): void {
    this.filter.title = '';
    this.filter.categoryId = '';
  }

  onClearSelectedQuestionFilter(): void {
    this.selectedFilter.title = '';
    this.selectedFilter.categoryId = '';
  }

  filteredSelectedQuestions(): Question[] {
    return this.selectedQuestions.filter(q =>
      (this.selectedFilter.categoryId ? q.questionCategory?.id === this.selectedFilter.categoryId : true) &&
      q.title.toLowerCase().includes(this.selectedFilter.title.toLowerCase())
    );
  }

  get groupedFilteredQuestions() {
    // Agrupa e ordena as questões disponíveis por categoria (usando nome)
    const filtered = this.filteredQuestions();
    const groups: { [cat: string]: Question[] } = {};
    filtered.forEach(q => {
      const cat = q.questionCategory?.name || 'Sem categoria';
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(q);
    });
    return Object.entries(groups).map(([category, questions]) => ({ category, questions }));
  }

  get groupedSelectedQuestions() {
    // Agrupa e ordena as questões selecionadas por categoria (usando descrição)
    const groups: { [cat: string]: Question[] } = {};
    this.selectedQuestions.forEach(q => {
      const desc = this.getCategoryDescription(q.questionCategory);
      if (!groups[desc]) groups[desc] = [];
      groups[desc].push(q);
    });
    const sortedCategories = Object.keys(groups).sort((a, b) => a.localeCompare(b));
    return sortedCategories.map(cat => ({
      category: cat,
      questions: groups[cat].sort((a, b) => a.title.localeCompare(b.title))
    }));
  }

  get groupedFilteredSelectedQuestions() {
    const filtered = this.filteredSelectedQuestions();
    const groups: { [cat: string]: Question[] } = {};
    filtered.forEach(q => {
      const cat = q.questionCategory?.name || 'Sem categoria';
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(q);
    });
    return Object.entries(groups).map(([category, questions]) => ({ category, questions }));
  }

  onCancel(): void {
    this.router.navigate(['../questionnaire'], { relativeTo: this.route });
  }

  get hasFullAccess(): boolean {
    return this.permissionService.hasFullAccess(CONST_PERMISSIONS.QUESTIONNAIRE);
  }

  getCategoryDescription(category: QuestionCategory | undefined): string {
    return category?.name || '';
  }

  addCategoryQuestions(categoryDesc: string, questions: Question[]): void {
    if (this.isViewMode || !this.hasFullAccess) return;
    questions.forEach(q => this.addQuestion(q));
  }

  removeCategoryQuestions(categoryDesc: string, questions: Question[]): void {
    if (this.isViewMode || !this.hasFullAccess) return;
    questions.forEach(q => this.removeQuestion(q));
  }
}
