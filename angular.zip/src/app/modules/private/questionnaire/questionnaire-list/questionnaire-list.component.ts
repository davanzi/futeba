import { Component, OnInit, inject } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PaginationComponent } from 'src/app/shared/components/pagination/pagination.component';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire.service';
import { DepartmentService } from 'src/app/shared/services/department.service';
import { CONST_PERMISSIONS } from 'src/app/shared/constants/permissions.const';
import { PermissionService } from 'src/app/core/services/permission.service';
import { Department } from 'src/app/shared/models/department.model';
import { Questionnaire } from 'src/app/shared/models/questionnaire.model';
import { QuestionCategory } from 'src/app/shared/models/question-category.model';

@Component({
  selector: 'app-questionnaire-list',
  standalone: true,
  templateUrl: './questionnaire-list.component.html',
  styleUrls: ['./questionnaire-list.component.scss'],
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatCheckboxModule,
    FormsModule,
    RouterModule,
    PaginationComponent
  ]
})
export class QuestionnaireListComponent implements OnInit {
  filter = { name: '', active: '', departmentId: '' };
  questionnaires: Questionnaire[] = [];
  departments: Department[] = [];
  totalElements = 0;
  pageSize = 10;
  pageIndex = 0;
  sort = 'name/asc';
  loading = false;

  readonly menuPermission = CONST_PERMISSIONS.QUESTIONNAIRE;
  constructor(
    public permissionService: PermissionService,
    private questionnaireService: QuestionnaireService = inject(QuestionnaireService),
    private departmentService: DepartmentService = inject(DepartmentService),
    private router: Router = inject(Router),
    private route: ActivatedRoute = inject(ActivatedRoute)
  ) {}

  get hasFullAccess(): boolean {
    return this.permissionService.hasFullAccess(CONST_PERMISSIONS.QUESTIONNAIRE);
  }

  ngOnInit(): void {
    this.loadDepartments();
    this.onSearch();
  }

  loadDepartments(): void {
    this.departmentService.searchDepartments({ name: '', active: true, id: null }, 0, 100).subscribe({
      next: (res) => {
        this.departments = (res?.data?.content && Array.isArray(res.data.content)) ? res.data.content : [];
      },
      error: () => {
        this.departments = [];
      }
    });
  }

  onSearch(): void {
    this.loading = true;
    const body: any = {
      id: null,
      name: this.filter.name || '',
      questionIds: [],
      template: true,
      active: this.filter.active === '' ? undefined : this.filter.active === 'true',
      department: this.filter.departmentId ? { id: this.filter.departmentId, name: '', active: true } : undefined
    };
    this.questionnaireService.searchQuestionnaires(body, this.pageIndex, this.pageSize, this.sort.replace('/', ',')).subscribe({
      next: (res) => {
        this.questionnaires = res.data.content || [];
        this.totalElements = res.data.totalElements || 0;
        this.loading = false;
      },
      error: () => {
        this.questionnaires = [];
        this.totalElements = 0;
        this.loading = false;
      }
    });
  }

  onClearFilters(): void {
    this.filter = { name: '', active: '', departmentId: '' };
    this.pageIndex = 0;
    this.onSearch();
  }

  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.onSearch();
  }

  onSortChange(field: string): void {
    const [currentField, currentOrder] = this.sort.split('/');
    if (currentField === field) {
      this.sort = `${field}/${currentOrder === 'asc' ? 'desc' : 'asc'}`;
    } else {
      this.sort = `${field}/asc`;
    }
    this.onSearch();
  }

  onEditQuestionnaire(q: Questionnaire): void {
    this.router.navigate(['../questionnaire-register'], { queryParams: { id: q.id }, relativeTo: this.route });
  }

  onViewQuestionnaire(q: Questionnaire): void {
    this.router.navigate(['../questionnaire-register'], { queryParams: { id: q.id, view: true }, relativeTo: this.route });
  }

  onChangeStatus(q: Questionnaire): void {
    if (!this.hasFullAccess) return;
    this.questionnaireService.changeStatus(q.id!).subscribe({
      next: () => {
        q.active = !q.active;
      }
    });
  }

  getDepartmentName(dept?: Department): string {
    return dept?.name || '';
  }

  // Se houver uso de categoria de questão, agora deve acessar questionCategory.name
  getCategoryDescription(category: QuestionCategory | undefined): string {
    return category?.name || '';
  }
}
