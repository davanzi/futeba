import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { QuestionService } from '../../../../shared/services/question.service';
import { Question } from '../../../../shared/models/question.model';
import { QuestionCategory } from '../../../../shared/models/question-category.model';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { take } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';
import { PaginationComponent } from '../../../../shared/components/pagination/pagination.component';
import { MatDialog } from '@angular/material/dialog';
import { QuestionDeleteDialogComponent } from '../question-delete-dialog.component';
import { LoadingService } from '../../../../shared/utils/loading/loading.service';
import { NotificationService } from '../../../../shared/services/notification.service';
import { PermissionService } from '../../../../core/services/permission.service';
import { CONST_PERMISSIONS } from '../../../../shared/constants/permissions.const';
import { AnswerType, AnswerTypeDescriptions } from '../../../../shared/constants/answer-type.enum';
import { QuestionCategoryService } from 'src/app/shared/services/question-category.service';

@Component({
  selector: 'app-question-list',
  standalone: true,
  templateUrl: './question-list.component.html',
  styleUrls: ['./question-list.component.scss'],
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    RouterModule,
    FormsModule,
    PaginationComponent
  ]
})
export class QuestionListComponent implements OnInit {
  displayedColumns: string[] = ['title', 'content', 'questionCategory', 'answerType', 'media', 'actions'];
  questions: Question[] = [];
  totalElements = 0;
  pageSize = 10;
  pageIndex = 0;
  sortField = 'title';
  sortOrder = 'asc';
  loading = false;
  filter = { title: '', content: '', questionCategoryId: '' };
  categories: QuestionCategory[] = [];
  AnswerTypeDescriptions = AnswerTypeDescriptions;

  private questionService = inject(QuestionService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private dialog = inject(MatDialog);
  private loadingService = inject(LoadingService);
  private notification = inject(NotificationService);
  private permissionService = inject(PermissionService);
  private questionCategoryService = inject(QuestionCategoryService);

  ngOnInit(): void {
    this.questionCategoryService.searchQuestionCategories({}, 0, 100).pipe(take(1)).subscribe((res: any) => {
      this.categories = (res?.data?.content && Array.isArray(res.data.content)) ? res.data.content : [];
    });
    this.route.queryParams.subscribe(params => {
      this.filter.title = params['title'] || '';
      this.filter.content = params['content'] || '';
      this.filter.questionCategoryId = params['questionCategoryId'] || '';
      this.pageIndex = params['page'] ? +params['page'] : 0;
      this.pageSize = params['size'] ? +params['size'] : 10;
      this.sortField = params['sortField'] || 'title';
      this.sortOrder = params['sortOrder'] || 'asc';
      this.loadQuestions();
    });
  }

  loadQuestions(page: number = this.pageIndex, size: number = this.pageSize, sort: string = `${this.sortField},${this.sortOrder}`): void {
    this.loading = true;
    this.loadingService.show();
    const body: any = {
      title: this.filter.title,
      content: this.filter.content,
      template: true
    };
    if (this.filter.questionCategoryId) {
      body.questionCategory = { id: this.filter.questionCategoryId };
    }
    this.questionService.searchQuestions(body, page, size, sort).subscribe({
      next: (res) => {
        this.questions = res.data.content || [];
        this.totalElements = res.data.totalElements || 0;
        this.loading = false;
        this.loadingService.hide();
      },
      error: () => {
        this.questions = [];
        this.totalElements = 0;
        this.loading = false;
        this.loadingService.hide();
      }
    });
  }

  onPageChange(event: PageEvent): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: {
        page: event.pageIndex,
        size: event.pageSize,
        sortField: this.sortField,
        sortOrder: this.sortOrder,
        ...this.filter
      },
      queryParamsHandling: 'merge'
    });
  }

  onSortChange(field: string): void {
    this.sortField = field;
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: {
        sortField: this.sortField,
        sortOrder: this.sortOrder,
        ...this.filter
      },
      queryParamsHandling: 'merge'
    });
  }

  onSearch(): void {
    this.pageIndex = 0;
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: {
        page: 0,
        size: this.pageSize,
        sortField: this.sortField,
        sortOrder: this.sortOrder,
        ...this.filter
      },
      queryParamsHandling: 'merge'
    });
  }

  onClearFilters(): void {
    this.filter = { title: '', content: '', questionCategoryId: '' };
    this.onSearch();
  }

  getCategoryDescription(category: QuestionCategory | undefined): string {
    return category?.name || '';
  }

  getAnswerTypeDescription(answerType: string): string {
    return this.AnswerTypeDescriptions[answerType as AnswerType] || answerType;
  }

  onRegister(): void {
    this.router.navigate(['../question-register'], { relativeTo: this.route });
  }

  onEditQuestion(q: Question): void {
    if (!this.hasQuestionFullAccess) return;
    if (!q) {
      this.notification.showError('Questão inválida para edição.');
      return;
    }
    this.router.navigate(['../question-register'], { relativeTo: this.route, queryParams: { id: q.id } });
  }

  onDeleteQuestion(q: Question): void {
    if (!this.hasQuestionFullAccess) return;
    if (!q.id) return;
    const dialogRef = this.dialog.open(QuestionDeleteDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loading = true;
        this.questionService.deleteQuestion(q.id!).subscribe({
          next: () => {
            this.loadQuestions();
          },
          error: () => {
            this.loading = false;
          }
        });
      }
    });
  }

  onViewQuestion(q: Question): void {
    if (!q) {
      this.notification.showError('Questão inválida para visualização.');
      return;
    }
    this.router.navigate(['../question-register'], {
      relativeTo: this.route,
      queryParams: { id: q.id, view: 'true' }
    });
  }

  get hasQuestionFullAccess(): boolean {
    return this.permissionService.hasFullAccess(`${CONST_PERMISSIONS.QUESTION}`);
  }

  compareCategory = (a: any, b: any): boolean => {
    return String(a) === String(b);
  };
}
