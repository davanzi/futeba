import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { QuestionService } from '../../../../shared/services/question.service';
import { NotificationService } from '../../../../shared/services/notification.service';
import { MediaService } from '../../../../shared/services/media.service';
import { PermissionService } from '../../../../core/services/permission.service';
import { Question, AnswerOption } from '../../../../shared/models/question.model';
import { QuestionCategory } from '../../../../shared/models/question-category.model';
import { take } from 'rxjs/operators';
import { environment } from '../../../../../environments/environment';
import { CONST_PERMISSIONS } from '../../../../shared/constants/permissions.const';
import { AnswerType, AnswerTypeDescriptions } from '../../../../shared/constants/answer-type.enum';
import { QuestionCategoryService } from 'src/app/shared/services/question-category.service';


import { QuillModule } from 'ngx-quill';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-question-register',
  standalone: true,
  templateUrl: './question-register.component.html',
  styleUrls: ['./question-register.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatRadioModule,
    MatCheckboxModule,
    RouterModule,
    QuillModule
  ]
})
export class QuestionRegisterComponent {
  public environment = environment;

  question: Question = {
    id: null,
    title: '',
    content: '',
    questionCategory: { id: null, name: '', active: true },
    video: null,
    image: null,
    answer: {
      id: null,
      answerType: AnswerType.DESCRIPTIVE,
      descriptiveContent: '',
      answerOptions: [
        { id: null, description: '', correct: false }
      ]
    },
    template: true
  };
  profileImagePreview: string = '';
  isEditMode: boolean = false;
  isViewMode: boolean = false;
  loading = false;
  error = '';
  categories: QuestionCategory[] = [];
  answerType = AnswerType.DESCRIPTIVE;
  AnswerType = AnswerType;
  AnswerTypeDescriptions = AnswerTypeDescriptions;
  hasFullAccessQuestion: boolean = true;

  compareCategory = (a: any, b: any): boolean => {
    return a && b && String(a.id) === String(b.id);
  };

  private questionCategoryService = inject(QuestionCategoryService);

  constructor(
    private questionService: QuestionService,
    private notification: NotificationService,
    private route: ActivatedRoute,
    private mediaService: MediaService,
    private permissionService: PermissionService,
    private titleService: Title
  ) {
    this.questionCategoryService.searchQuestionCategories({}, 0, 100).pipe(take(1)).subscribe((res: any) => {
      this.categories = (res?.data?.content && Array.isArray(res.data.content)) ? res.data.content : [];
    });
    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.loadQuestion(params['id']);
      } else {
        this.isEditMode = false;
        this.resetQuestion();
      }
      this.isViewMode = params['view'] === 'true';
      if (this.isViewMode) {
        this.titleService.setTitle('Visualizar Questão');
      } else if (this.isEditMode) {
        this.titleService.setTitle('Editar Questão');
      } else {
        this.titleService.setTitle('Cadastrar Questão');
      }
    });
    this.hasFullAccessQuestion = this.permissionService.hasFullAccess(`${CONST_PERMISSIONS.QUESTION}`);
  }

  loadQuestion(id: string) {
    this.loading = true;
    this.questionService.searchQuestions({ id }, 0, 1).subscribe({
      next: (res: any) => {
        const q = res.data.content[0];
        if (q) {
          this.question = {
            id: q.id,
            title: q.title,
            content: q.content,
            questionCategory: q.questionCategory,
            video: typeof q.video === 'string' ? q.video : null,
            image: typeof q.image === 'string' ? q.image : null,
            answer: {
              id: q.answer?.id ?? null,
              answerType: (q.answer?.answerType as AnswerType) || AnswerType.DESCRIPTIVE,
              descriptiveContent: q.answer?.descriptiveContent || '',
              answerOptions: q.answer?.answerOptions?.map((opt: any) => {
                if (
                  q.answer?.answerType === AnswerType.MULTIPLE_CHOICE_IMAGE ||
                  q.answer?.answerType === AnswerType.SINGLE_CHOICE_IMAGE
                ) {
                  // Sempre garantir que opt.image tenha o valor correto
                  return {
                    id: opt.id ?? null,
                    image: opt.image || opt.description || '',
                    correct: opt.correct
                  };
                } else {
                  return {
                    id: opt.id ?? null,
                    description: opt.description,
                    correct: opt.correct
                  };
                }
              }) || [{ id: null, description: '', correct: false }]
            },
            template: q.template
          };
          this.answerType = (q.answer?.answerType as AnswerType) || AnswerType.DESCRIPTIVE;
        }
        this.loading = false;
      },
      error: () => {
        this.notification.showError('Erro ao carregar questão para edição.');
        this.loading = false;
      }
    });
  }

  onFileChange(event: any, type: 'video' | 'image') {
    const file = event.target.files[0];
    if (!file) return;
    this.loading = true;
    if (type === 'video') {
      this.mediaService.uploadVideo(file).subscribe({
        next: (res: any) => {
          if (res && res.data && res.data.video) {
            this.question.video = res.data.video;
          }
        },
        error: () => {
          this.notification.showError('Erro ao fazer upload do vídeo.');
        },
        complete: () => {
          this.loading = false;
        }
      });
    } else {
      this.mediaService.uploadImage(file).subscribe({
        next: (res: any) => {
          if (res && res.data && res.data.image) {
            this.question.image = res.data.image;
          }
        },
        error: () => {
          this.notification.showError('Erro ao fazer upload da imagem.');
        },
        complete: () => {
          this.loading = false;
        }
      });
    }
  }

  removeVideo() {
    this.question.video = null;
  }

  removeImage() {
    this.question.image = null;
  }

  onAddOption() {
    if (this.answerType === AnswerType.MULTIPLE_CHOICE_IMAGE || this.answerType === AnswerType.SINGLE_CHOICE_IMAGE) {
      this.question.answer!.answerOptions!.push({ id: null, image: '', correct: false });
    } else {
      this.question.answer!.answerOptions!.push({ id: null, description: '', correct: false });
    }
  }

  onRemoveOption(idx: number) {
    if (this.question.answer!.answerOptions!.length > 1) {
      this.question.answer!.answerOptions!.splice(idx, 1);
    }
  }

  onAnswerTypeChange() {
    if (
      this.answerType === AnswerType.MULTIPLE_CHOICE_TEXT ||
      this.answerType === AnswerType.SINGLE_CHOICE_TEXT
    ) {
      if (this.answerType === AnswerType.SINGLE_CHOICE_TEXT) {
        const firstCorrectIdx = this.question.answer!.answerOptions!.findIndex(opt => opt.correct);
        this.question.answer!.answerOptions!.forEach((opt, i) => {
          opt.correct = i === firstCorrectIdx && firstCorrectIdx !== -1;
        });
      }
      this.question.answer!.descriptiveContent = '';
      this.question.answer!.answerOptions!.forEach(opt => { delete opt.image; });
      this.question.answer!.answerOptions = this.question.answer!.answerOptions!.map(opt => ({ id: opt.id ?? null, description: opt.description || '', correct: opt.correct }));
    } else if (
      this.answerType === AnswerType.MULTIPLE_CHOICE_IMAGE ||
      this.answerType === AnswerType.SINGLE_CHOICE_IMAGE
    ) {
      // Não remover o campo image, apenas garantir que description não atrapalhe
      this.question.answer!.answerOptions!.forEach(opt => { delete opt.description; });
      this.question.answer!.answerOptions = this.question.answer!.answerOptions!.map(opt => ({ id: opt.id ?? null, image: opt.image || '', correct: opt.correct }));
      this.question.answer!.descriptiveContent = '';
      // Se for single, garantir apenas um correto
      if (this.answerType === AnswerType.SINGLE_CHOICE_IMAGE) {
        const firstCorrectIdx = this.question.answer!.answerOptions!.findIndex(opt => opt.correct);
        this.question.answer!.answerOptions!.forEach((opt, i) => {
          opt.correct = i === firstCorrectIdx && firstCorrectIdx !== -1;
        });
      }
    } else if (this.answerType === AnswerType.EDITOR || this.answerType === AnswerType.DESCRIPTIVE) {
      this.question.answer!.answerOptions = [{ id: null, description: '', correct: false }];
      this.question.answer!.descriptiveContent = '';
    }
  }

  onOptionImageChange(event: any, idx: number) {
    const file = event.target.files[0];
    if (!file) return;
    this.loading = true;
    this.mediaService.uploadImage(file).subscribe({
      next: (res: any) => {
        if (res && res.data && res.data.image) {
          if (!this.question.answer!.answerOptions![idx]) return;
          this.question.answer!.answerOptions![idx].image = res.data.image;
          this.question.answer!.answerOptions![idx].description = res.data.image;
        }
      },
      error: () => {
        this.notification.showError('Erro ao fazer upload da imagem da alternativa.');
      },
      complete: () => {
        this.loading = false;
      }
    });
  }

  onOptionCorrectChange(idx: number) {
    if (
      this.answerType === AnswerType.SINGLE_CHOICE_TEXT ||
      this.answerType === AnswerType.SINGLE_CHOICE_IMAGE
    ) {
      this.question.answer!.answerOptions!.forEach((opt, i) => opt.correct = i === idx);
    }
  }

  onSubmit() {
    this.loading = true;
    this.error = '';
    const answerOptions =
      this.answerType !== AnswerType.DESCRIPTIVE && this.answerType !== AnswerType.EDITOR
        ? this.question.answer?.answerOptions?.map(opt => {
            if (
              this.answerType === AnswerType.MULTIPLE_CHOICE_IMAGE ||
              this.answerType === AnswerType.SINGLE_CHOICE_IMAGE
            ) {
              return {
                id: this.isEditMode && opt.id ? opt.id : null,
                description: opt.image || '', // Envia a imagem em description
                correct: opt.correct
              };
            } else {
              return {
                id: this.isEditMode && opt.id ? opt.id : null,
                description: opt.description,
                correct: opt.correct
              };
            }
          })
        : undefined;
    const payload: Question = {
      id: this.isEditMode ? this.question.id : null,
      title: this.question.title,
      content: this.question.content,
      video: this.question.video ? this.question.video : null,
      image: this.question.image ? this.question.image : null,
      answer: {
        id: this.isEditMode && this.question.answer?.id ? this.question.answer.id : null,
        answerType: this.answerType,
        descriptiveContent: (this.answerType === AnswerType.DESCRIPTIVE || this.answerType === AnswerType.EDITOR)
          ? this.question.answer?.descriptiveContent
          : undefined,
        answerOptions
      },
      questionCategory: this.question.questionCategory, // já é objeto
      template: true
    };
    const request$ = this.isEditMode
      ? this.questionService.registerOrUpdateQuestion(payload)
      : this.questionService.registerOrUpdateQuestion(payload);
    request$.subscribe({
      next: () => {
        this.loading = false;
        this.notification.showInfo(this.isEditMode ? 'Questão atualizada com sucesso!' : 'Questão cadastrada com sucesso!');
        window.history.back();
      },
      error: (err: any) => {
        this.loading = false;
        this.error = err;
        this.notification.showError('Erro ao salvar questão: ' + err);
      }
    });
  }

  onCancel(): void {
    history.back();
  }

  onClear() {
    this.resetQuestion();
  }

  resetQuestion() {
    this.question = {
      id: null,
      title: '',
      content: '',
      questionCategory: { id: null, name: '', active: true },
      video: null,
      image: null,
      answer: {
        id: null,
        answerType: AnswerType.DESCRIPTIVE,
        descriptiveContent: '',
        answerOptions: [
          { id: null, description: '', correct: false }
        ]
      },
      template: true
    };
    this.answerType = AnswerType.DESCRIPTIVE;
    this.error = '';
  }

  triggerOptionImageInput(idx: number) {
    const input = document.getElementById('imgInput' + idx) as HTMLInputElement;
    if (input && !input.disabled) {
      input.click();
    }
  }
}
