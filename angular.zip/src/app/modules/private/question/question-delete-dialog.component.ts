import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-question-delete-dialog',
  template: `
    <mat-dialog-content>
      Tem certeza que deseja excluir esta questão?
    </mat-dialog-content>
    <mat-dialog-actions>
      <button mat-raised-button (click)="onNo()">Não</button>
      <button mat-raised-button color="warn" (click)="onYes()">Sim</button>
    </mat-dialog-actions>
  `,
  standalone: true,
  imports: [MatDialogModule, MatButtonModule],
})
export class QuestionDeleteDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<QuestionDeleteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  onNo(): void {
    this.dialogRef.close(false);
  }

  onYes(): void {
    this.dialogRef.close(true);
  }
}

export {};
