import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UserService } from '../../../shared/services/user.service';
import { Router } from '@angular/router';
import { NotificationService } from '../../../shared/services/notification.service';
import { LoadingService } from '../../../shared/utils/loading/loading.service';
import { PasswordStrengthComponent } from '../../../shared/password-strength/password-strength.component';
import { EncryptionService } from '../../../shared/utils/encryption/encryption.service';
import { AuthService } from '../../../core/services/auth.service';
import { CONST_ROUTES } from '../../../shared/constants/routes.const';

@Component({
  selector: 'app-update-password',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    RouterModule,
    PasswordStrengthComponent
  ],
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.scss']
})
export class UpdatePasswordComponent {
  hidePassword: boolean = true;
  hideRepeatPassword: boolean = true;
  password: string = '';
  repeatPassword: string = '';
  mismatchMessage: string = '';

  constructor(
    private userService: UserService,
    private router: Router,
    private notificationService: NotificationService,
    private loadingService: LoadingService,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) { }

  togglePasswordVisibility(event: Event, field: 'password' | 'repeatPassword'): void {
    event.preventDefault();
    if (field === 'password') {
      this.hidePassword = !this.hidePassword;
    } else {
      this.hideRepeatPassword = !this.hideRepeatPassword;
    }
  }

  validatePasswordMatch(): void {
    if (this.repeatPassword.length > 0 && this.password !== this.repeatPassword) {
      this.mismatchMessage = 'As senhas não coincidem';
    } else {
      this.mismatchMessage = '';
    }
  }

  updatePassword(): void {
    if (!this.password || !this.repeatPassword) {
      this.notificationService.showError('Por favor, preencha todos os campos.');
      return;
    }

    if (this.password !== this.repeatPassword) {
      this.notificationService.showError('As senhas não coincidem.');
      return;
    }

    const userId = this.authService.getUserId();
    if (!userId) {
      this.notificationService.showError('Usuário não autenticado.');
      return;
    }

    this.loadingService.show();
    this.userService.updateUser({ id: String(userId), password: this.encryptionService.encrypt(this.password) }).subscribe({
      next: () => {
        this.notificationService.showInfo('Senha atualizada com sucesso!');
        this.router.navigate([CONST_ROUTES.HOME.route]);
      },
      error: (err: any) => {
        this.notificationService.showError(err.toString());
      }
    }).add(() => {
      this.loadingService.hide();
    });
  }
}