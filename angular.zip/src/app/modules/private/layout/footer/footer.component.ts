import { Component } from '@angular/core';
import { VersionComponent } from '../../../../shared/utils/version/version.component';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
  standalone: true,
  imports: [VersionComponent],
})
export class FooterComponent {
  currentYear = new Date().getFullYear();
}
