import { Component, Input, Output, EventEmitter } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  standalone: true,
  imports: [CommonModule, MatToolbarModule, MatIconModule, MatMenuModule],
})
export class HeaderComponent {
  @Input() isSidenavOpen: boolean = true;
  @Input() userName: string = '';
  @Input() userProfileImage: string | null = null;
  @Output() toggleSidenav = new EventEmitter<void>();
  @Output() goToAccount = new EventEmitter<void>();
  @Output() logout = new EventEmitter<void>();
}
