import { Component } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { RouterModule, Router, NavigationEnd } from '@angular/router';
import { CONST_PERMISSIONS } from '../../../../shared/constants/permissions.const';
import { AuthService } from '../../../../core/services/auth.service';
import { UserService } from '../../../../shared/services/user.service';
import { EncryptionService } from '../../../../shared/utils/encryption/encryption.service';
import { environment } from '../../../../../environments/environment';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { FooterComponent } from '../footer/footer.component';
import { HeaderComponent } from '../header/header.component';
import { CONST_ROUTES } from '../../../../shared/constants/routes.const';

interface MenuItem {
  label: string;
  route?: string;
  permission?: string;
  icon?: string;
  children?: MenuItem[];
}

const ALL_MENUS: MenuItem[] = [
  { label: 'Home', route: CONST_ROUTES.HOME.route, permission: CONST_PERMISSIONS.HOME, icon: 'home' },
  {
    label: 'Configurações',
    icon: 'settings',
    children: [
      { label: 'Usuário', route: CONST_ROUTES.USER.route, permission: CONST_PERMISSIONS.USER, icon: 'person' },
      { label: 'Departamento', route: CONST_ROUTES.DEPARTMENT.route, permission: CONST_PERMISSIONS.DEPARTMENT, icon: 'apartment' }
    ]
  },
  {
    label: 'Recursos Humanos',
    icon: 'groups',
    children: [
      {
        label: 'Processo Seletivo',
        icon: 'assignment',
        children: [
          {
            label: 'Modelo',
            icon: 'view_list',
            children: [
              { label: 'Categoria', route: CONST_ROUTES.QUESTION_CATEGORY.route, permission: CONST_PERMISSIONS.QUESTION_CATEGORY, icon: 'category' },
              { label: 'Questões', route: CONST_ROUTES.QUESTION.route, permission: CONST_PERMISSIONS.QUESTION, icon: 'quiz' },
              { label: 'Questionários', route: CONST_ROUTES.QUESTIONNAIRE.route, permission: CONST_PERMISSIONS.QUESTIONNAIRE, icon: 'checklist' }
            ],
          },
        ],
      }
    ],
  },
];

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatMenuModule,
    RouterModule,
    FooterComponent,
    HeaderComponent,
  ],
})
export class MenuComponent {
  isSidenavOpen = true;
  sidenavMode: 'side' | 'over' = 'side';
  menus: MenuItem[] = [];
  userProfileImage: string | null = null;
  user: any = null;
  private userSub: Subscription;
  expandedMenu: string | null = null;
  expandedSubMenu: string | null = null;
  currentRoute: string = '';
  expandedPath: string[] = [];

  constructor(
    private authService: AuthService,
    private router: Router,
    private userService: UserService,
    private encryptionService: EncryptionService,
    private breakpointObserver: BreakpointObserver
  ) {
    this.userSub = this.authService.user$.subscribe((user: any) => {
      this.user = user;
      this.setMenusByProfile();
      this.setUserProfileImage();
    });
    this.initUserAndMenus();
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.urlAfterRedirects;
      }
    });
    this.breakpointObserver.observe([`(max-width: 799px)`]).subscribe(result => {
      if (result.matches) {
        this.sidenavMode = 'over';
        this.isSidenavOpen = false;
      } else {
        this.sidenavMode = 'side';
        this.isSidenavOpen = true;
      }
    });
  }

  async initUserAndMenus() {
    // Tenta pegar o user do AuthService (memória)
    this.user = this.authService.getUser();
    this.setMenusByProfile();
    this.setUserProfileImage();
  }

  setMenusByProfile(): void {
    if (!this.user) {
      this.menus = [];
      return;
    }
    const profileNames = this.user.profiles?.map((p: any) => p.permission?.name?.toUpperCase()) || [];
    const isMaster = profileNames.includes(`${CONST_PERMISSIONS.MASTER}`);
    if (isMaster) {
      this.menus = ALL_MENUS;
    } else {
      // Filtro recursivo: se algum filho for permitido, mantém toda a cadeia de pais
      const filterMenus = (menus: MenuItem[]): MenuItem[] =>
        menus
          .map(menu => {
            if (menu.children) {
              const filteredChildren = filterMenus(menu.children);
              if (filteredChildren.length > 0) {
                return { ...menu, children: filteredChildren };
              }
            }
            if (menu.permission && profileNames.includes(menu.permission)) {
              return { ...menu };
            }
            return null;
          })
          .filter(Boolean) as MenuItem[];
      this.menus = filterMenus(ALL_MENUS);
    }
  }

  setUserProfileImage(): void {
    if (this.user && this.user.profileImage) {
      this.userProfileImage = `${environment.apiMultimidiaUrl}${this.user.profileImage}`;
    } else {
      this.userProfileImage = null;
    }
  }

  toggleSidenav(): void {
    this.isSidenavOpen = !this.isSidenavOpen;
  }

  logout(): void {
    this.authService.logout();
  }

  get userName(): string {
    return this.user?.name || '';
  }

  goToAccount() {
    this.router.navigate([CONST_ROUTES.ACCOUNT.route]);
  }

  onMenuPathClick(path: string[]): void {
    // Se já está expandido, fecha; senão, abre apenas esse caminho
    if (this.isPathExpanded(path)) {
      this.expandedPath = path.slice(0, -1);
    } else {
      this.expandedPath = path;
    }
  }

  isPathExpanded(path: string[]): boolean {
    if (this.expandedPath.length < path.length) return false;
    for (let i = 0; i < path.length; i++) {
      if (this.expandedPath[i] !== path[i]) return false;
    }
    return true;
  }

  onMenuItemClick(menu: MenuItem, path: string[]): void {
    if (menu.children && menu.children.length > 0) {
      this.onMenuPathClick(path);
    } else if (menu.route) {
      console.log(`Navegando para: ${menu.route}`);
      this.expandedPath = path.slice(0, -1); // Fecha menus ao navegar
    }
  }

  isMenuItemSelected(menu: MenuItem): boolean {
    return !!menu.route && this.currentRoute === menu.route;
  }

  ngOnDestroy() {
    this.userSub.unsubscribe();
  }
}
