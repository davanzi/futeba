import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { QuestionCategoryService } from 'src/app/shared/services/question-category.service';
import { QuestionCategory } from 'src/app/shared/models/question-category.model';
import { PermissionService } from 'src/app/core/services/permission.service';
import { CONST_PERMISSIONS } from 'src/app/shared/constants/permissions.const';

@Component({
  selector: 'app-question-category-register',
  standalone: true,
  templateUrl: './question-category-register.component.html',
  styleUrls: ['./question-category-register.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    RouterModule
  ]
})
export class QuestionCategoryRegisterComponent implements OnInit {
  questionCategory: QuestionCategory = { id: null, name: '', active: true };
  isEditMode = false;
  isViewMode = false;
  loading = false;
  error = '';

  private questionCategoryService = inject(QuestionCategoryService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private permissionService = inject(PermissionService);

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.loading = true;
        this.questionCategoryService.searchQuestionCategories({ id: params['id'] }, 0, 1).subscribe({
          next: (res) => {
            const d = res.data.content[0];
            if (d) this.questionCategory = d;
            this.loading = false;
          },
          error: () => { this.loading = false; }
        });
      }
      this.isViewMode = params['view'] === 'true';
    });
  }

  onSubmit(): void {
    if (this.isViewMode) return;
    this.loading = true;
    this.questionCategoryService.registerOrUpdate(this.questionCategory).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigate(['../question-category'], { relativeTo: this.route });
      },
      error: (err) => {
        this.loading = false;
        this.error = err;
      }
    });
  }

  onClear(): void {
    if (this.isViewMode) return;
    this.questionCategory = { id: null, name: '', active: true };
  }

  onCancel(): void {
    this.router.navigate(['../question-category'], { relativeTo: this.route });
  }

  get hasFullAccess(): boolean {
    return this.permissionService.hasFullAccess(CONST_PERMISSIONS.QUESTION_CATEGORY);
  }
}
