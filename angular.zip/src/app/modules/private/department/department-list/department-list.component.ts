import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { DepartmentService } from 'src/app/shared/services/department.service';
import { Department } from 'src/app/shared/models/department.model';
import { PermissionService } from 'src/app/core/services/permission.service';
import { CONST_PERMISSIONS } from 'src/app/shared/constants/permissions.const';
import { PaginationComponent } from 'src/app/shared/components/pagination/pagination.component';

@Component({
  selector: 'app-department-list',
  standalone: true,
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.scss'],
  imports: [
    CommonModule,
    MatTableModule,
    MatIconModule,
    MatCardModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    FormsModule,
    RouterModule,
    PaginationComponent
  ]
})
export class DepartmentListComponent implements OnInit {
  displayedColumns: string[] = ['active', 'name', 'actions'];
  dataSource: Department[] = [];
  totalElements = 0;
  pageSize = 10;
  pageIndex = 0;
  sortField = 'name';
  sortOrder = 'asc';
  filter = { name: '', active: '' };
  loading = false;

  private departmentService = inject(DepartmentService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private permissionService = inject(PermissionService);

  ngOnInit(): void {
    this.onSearch();
  }

  onSearch(): void {
    this.loading = true;
    const body: any = {
      name: this.filter.name,
      active: this.filter.active === '' ? null : this.filter.active === 'true',
      id: null
    };
    this.departmentService.searchDepartments(body, this.pageIndex, this.pageSize, `${this.sortField},${this.sortOrder}`).subscribe({
      next: (res) => {
        this.dataSource = res.data.content;
        this.totalElements = res.data.totalElements;
        this.pageSize = res.data.size;
        this.pageIndex = res.data.number;
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  onClearFilters(): void {
    this.filter = { name: '', active: '' };
    this.onSearch();
  }

  onRegister(): void {
    this.router.navigate(['../department-register'], { relativeTo: this.route });
  }

  onEdit(dept: Department): void {
    this.router.navigate(['../department-register'], { relativeTo: this.route, queryParams: { id: dept.id } });
  }

  onView(dept: Department): void {
    this.router.navigate(['../department-register'], { relativeTo: this.route, queryParams: { id: dept.id, view: true } });
  }

  onChangeStatus(dept: Department): void {
    if (!this.hasFullAccess) return;
    this.departmentService.changeStatus(dept.id!).subscribe({
      next: () => this.onSearch(),
      error: () => {}
    });
  }

  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.onSearch();
  }

  get hasFullAccess(): boolean {
    return this.permissionService.hasFullAccess(CONST_PERMISSIONS.DEPARTMENT);
  }
}
