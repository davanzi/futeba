import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { DepartmentService } from 'src/app/shared/services/department.service';
import { Department } from 'src/app/shared/models/department.model';
import { PermissionService } from 'src/app/core/services/permission.service';
import { CONST_PERMISSIONS } from 'src/app/shared/constants/permissions.const';

@Component({
  selector: 'app-department-register',
  standalone: true,
  templateUrl: './department-register.component.html',
  styleUrls: ['./department-register.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    RouterModule
  ]
})
export class DepartmentRegisterComponent implements OnInit {
  department: Department = { id: null, name: '', active: true };
  isEditMode = false;
  isViewMode = false;
  loading = false;
  error = '';

  private departmentService = inject(DepartmentService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private permissionService = inject(PermissionService);

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.loading = true;
        this.departmentService.searchDepartments({ id: params['id'] }, 0, 1).subscribe({
          next: (res) => {
            const d = res.data.content[0];
            if (d) this.department = d;
            this.loading = false;
          },
          error: () => { this.loading = false; }
        });
      }
      this.isViewMode = params['view'] === 'true';
    });
  }

  onSubmit(): void {
    if (this.isViewMode) return;
    this.loading = true;
    this.departmentService.registerOrUpdate(this.department).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigate(['../department'], { relativeTo: this.route });
      },
      error: (err) => {
        this.loading = false;
        this.error = err;
      }
    });
  }

  onClear(): void {
    if (this.isViewMode) return;
    this.department = { id: null, name: '', active: true };
  }

  onCancel(): void {
    this.router.navigate(['../department'], { relativeTo: this.route });
  }

  get hasFullAccess(): boolean {
    return this.permissionService.hasFullAccess(CONST_PERMISSIONS.DEPARTMENT);
  }
}
