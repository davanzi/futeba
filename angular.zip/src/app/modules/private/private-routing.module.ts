import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UpdatePasswordComponent } from './update-password/update-password.component';
import { HomeComponent } from './home/home.component';
import { MenuComponent } from './layout/menu/menu.component';
import { AuthGuard } from '../../core/guards/auth.guard';
import { CONST_PERMISSIONS } from '../../shared/constants/permissions.const';
import { CONST_ROUTES } from '../../shared/constants/routes.const';

const routes: Routes = [
  {
    path: '',
    component: MenuComponent, // Use MenuComponent as the base layout
    canActivate: [AuthGuard],
    children: [
      { 
        path: CONST_ROUTES.HOME.path,
        component: HomeComponent
      },
      {
        path: CONST_ROUTES.USER.path,
        loadComponent: CONST_ROUTES.USER.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.USER}` }
      },
      {
        path: CONST_ROUTES.USER_REGISTER.path,
        loadComponent: CONST_ROUTES.USER_REGISTER.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.USER}` }
      },
      {
        path: CONST_ROUTES.QUESTION.path,
        loadComponent: CONST_ROUTES.QUESTION.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.QUESTION}` }
      },
      {
        path: CONST_ROUTES.QUESTION_REGISTER.path,
        loadComponent: CONST_ROUTES.QUESTION_REGISTER.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.QUESTION}` }
      },
      {
        path: CONST_ROUTES.QUESTIONNAIRE.path,
        loadComponent: CONST_ROUTES.QUESTIONNAIRE.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.QUESTIONNAIRE}` }
      },
      {
        path: CONST_ROUTES.QUESTIONNAIRE_REGISTER.path,
        loadComponent: CONST_ROUTES.QUESTIONNAIRE_REGISTER.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.QUESTIONNAIRE}` }
      },
      {
        path: CONST_ROUTES.ACCOUNT.path,
        loadComponent: CONST_ROUTES.ACCOUNT.import,
      },
      {
        path: CONST_ROUTES.DEPARTMENT.path,
        loadComponent: CONST_ROUTES.DEPARTMENT.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.DEPARTMENT}` }
      },
      {
        path: CONST_ROUTES.DEPARTMENT_REGISTER.path,
        loadComponent: CONST_ROUTES.DEPARTMENT_REGISTER.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.DEPARTMENT}` }
      },
      {
        path: CONST_ROUTES.QUESTION_CATEGORY.path,
        loadComponent: CONST_ROUTES.QUESTION_CATEGORY.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.QUESTION_CATEGORY}` }
      },
      {
        path: CONST_ROUTES.QUESTION_CATEGORY_REGISTER.path,
        loadComponent: CONST_ROUTES.QUESTION_CATEGORY_REGISTER.import,
        canActivate: [AuthGuard],
        data: { permission: `${CONST_PERMISSIONS.QUESTION_CATEGORY}` }
      },
      { path: '', redirectTo: CONST_ROUTES.HOME.path, pathMatch: 'full' },
    ],
  },
  { path: 'update-password', component: UpdatePasswordComponent, canActivate: [AuthGuard] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PrivateRoutingModule { }
