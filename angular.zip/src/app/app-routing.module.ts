import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Consolidando as rotas do app.routes.ts aqui
export const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('./modules/public/public-routing.module').then(m => m.PublicRoutingModule),
  },
  {
    path: 'app',
    loadChildren: () =>
      import('./modules/private/private-routing.module').then(m => m.PrivateRoutingModule),
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
